import mockjs from 'mockjs';
import { format, delay } from 'roadhog-api-doc';

// 是否禁用代理
const noProxy = process.env.NO_PROXY === 'true';
const baseUrl = '/api';
const getReuslt = (data, ok = true, errMsg = '系统异常', status = 0) => ({
  status,
  ok,
  data,
  errMsg,
});
// 代码中会兼容本地 service mock 以及部署站点的静态数据
const proxyObj = {};
proxyObj[`GET ${baseUrl}/admin/checkLogin`] = (req, res) => {
  res.status(200).send(
    getReuslt({
      id: '123456789',
      name: 'hello',
    })
  );
};

const proxy = proxyObj;
export default (noProxy ? {} : delay(proxy, 1000));
