export function fixedZero(val) {
  return val * 1 < 10 ? `0${val}` : val;
}

export function deleCookies() {
  const myDate = new Date();
  myDate.setTime(-1000); // 设置时间
  const data = document.cookie;
  const dataArray = data.split('; ');
  for (let i = 0; i < dataArray.length; i += 1) {
    const varName = dataArray[i].split('=');
    document.cookie = `${varName[0]}=''; expires=${myDate.toGMTString()}`;
  }
  const domain = document.domain.replace(/^\w*\./, '');
  document.cookie = `JSESSIONID='';domain=${domain}`;
}

export function getDate(date) {
  const y = date.getFullYear();
  const m = date.getMonth() + 1 > 9 ? date.getMonth() + 1 : `0${date.getMonth() + 1}`;
  const d = date.getDate() > 9 ? date.getDate() : `0${date.getDate()}`;
  const day = `${y}-${m}-${d}`;
  return day;
}

export function getPlainNode(nodeList, parentPath = '') {
  const arr = [];
  nodeList.forEach(node => {
    const item = node;
    item.path = `${parentPath}/${item.path || ''}`.replace(/\/+/g, '/');
    item.exact = true;
    if (item.children && !item.component) {
      arr.push(...getPlainNode(item.children, item.path));
    } else {
      if (item.children && item.component) {
        item.exact = false;
      }
      arr.push(item);
    }
  });
  return arr;
}

export function digitUppercase(n) {
  const fraction = ['角', '分'];
  const digit = ['零', '壹', '贰', '叁', '肆', '伍', '陆', '柒', '捌', '玖'];
  const unit = [['元', '万', '亿'], ['', '拾', '佰', '仟']];
  let num = Math.abs(n);
  let s = '';
  fraction.forEach((item, index) => {
    s += (digit[Math.floor(num * 10 * 10 ** index) % 10] + item).replace(/零./, '');
  });
  s = s || '整';
  num = Math.floor(num);
  for (let i = 0; i < unit[0].length && num > 0; i += 1) {
    let p = '';
    for (let j = 0; j < unit[1].length && num > 0; j += 1) {
      p = digit[num % 10] + unit[1][j] + p;
      num = Math.floor(num / 10);
    }
    s = p.replace(/(零.)*零$/, '').replace(/^$/, '零') + unit[0][i] + s;
  }

  return s
    .replace(/(零.)*零元/, '元')
    .replace(/(零.)+/g, '零')
    .replace(/^整$/, '零元整');
}

function getRelation(str1, str2) {
  if (str1 === str2) {
    console.warn('Two path are equal!'); // eslint-disable-line
  }
  const arr1 = str1.split('/');
  const arr2 = str2.split('/');
  if (arr2.every((item, index) => item === arr1[index])) {
    return 1;
  }
  if (arr1.every((item, index) => item === arr2[index])) {
    return 2;
  }
  return 3;
}

function getRenderArr(routes) {
  let renderArr = [];
  renderArr.push(routes[0]);
  for (let i = 1; i < routes.length; i += 1) {
    let isAdd = false;
    // 是否包含
    isAdd = renderArr.every(item => getRelation(item, routes[i]) === 3);
    // 去重
    renderArr = renderArr.filter(item => getRelation(item, routes[i]) !== 1);
    if (isAdd) {
      renderArr.push(routes[i]);
    }
  }
  return renderArr;
}

/**
 * Get router routing configuration
 * { path:{name,...param}}=>Array<{name,path ...param}>
 * @param {string} path
 * @param {routerData} routerData
 */
export function getRoutes(path, routerData, depth) {
  const routes = Object.keys(routerData).filter(
    routePath => routePath.indexOf(path) === 0 && routePath !== path
  );
  if (routes.length === 0) return [];
  // Replace path to '' eg. path='user' /user/name => name
  const routeArr = routes.map(item => item.replace(path, ''));
  // Get the route to be rendered to remove the deep rendering
  const renderArr = getRenderArr(routeArr).map(route => `${path}${route}`);
  let renderRoutes = renderArr.map(item => {
    const exact = !routes.some(route => route !== item && getRelation(route, item) === 1);
    return {
      exact,
      ...routerData[`${item}`],
      key: `${item}`,
      path: `${item}`,
    };
  });
  if (depth !== 0) {
    renderRoutes = renderRoutes.concat(
      ...renderArr.map(item =>
        getRoutes(item, routerData, typeof depth === 'number' && depth > 0 ? depth - 1 : undefined)
      )
    );
  }
  return renderRoutes;
}

/* eslint no-useless-escape:0 */
const reg = /(((^https?:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)$/g;

export function isUrl(path) {
  return reg.test(path);
}

export const downloadSheet = (blob, name, url) => {
  let aUrl = null;
  if (!url) {
    if (!blob) return;
    aUrl = window.URL.createObjectURL(blob);
  } else {
    aUrl = url;
  }
  const a = document.createElement('a');
  a.href = aUrl;
  if (name) a.download = name;
  a.click();
  if (!url) window.URL.revokeObjectURL(aUrl);
};

/* eslint-disable  no-param-reassign  */
export const debounceFun = (func, wait = 200) => {
  let timeout;
  function f(...args) {
    const context = this;
    if (timeout) clearTimeout(timeout);
    timeout = setTimeout(() => {
      func.apply(context, args);
    }, wait);
  }
  f.name = func.name;
  return f;
};
