import axios from 'axios';
import { message, Modal } from 'antd';
import { loginUrl } from '@/utils/property';

axios.defaults.timeout = 60000;
axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';

axios.interceptors.request.use(config => config, err => Promise.reject(err));
axios.interceptors.response.use(
  res => {
    // 取消lid对应的loading
    // cas 跳转登录
    if (res && res.data) {
      const { ok, status, data, errMsg, msg } = res.data;
      if (status === 302) {
        Modal.info({
          title: '未登录',
          content: '请先登录',
          centered: true,
          onOk: () => {
            // 跳转到登录页面
            window.location.href = loginUrl;
          },
        });
        return null;
      }
      if (ok) {
        return [null, undefined].includes(data) ? true : data; // 兼容 data 为 null 或者 undefined的行为
      }
      if (errMsg || msg) {
        message.error(errMsg || msg);
        return null;
      }
      return res.data;
    }
    return res;
  },
  err => {
    message.error(err.toString());
    // Promise.reject(err.response);
    return null;
  }
);
export default axios;
