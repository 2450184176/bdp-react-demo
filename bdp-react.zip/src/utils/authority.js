// use localStorage to store the authority info, which might be sent from server in actual project.
export function getAuthority() {
  const auth = localStorage.getItem('antd-pro-authority');
  return JSON.parse(auth || JSON.stringify(['gest']));
}

export function setAuthority(authority = []) {
  let auths = [];
  if (Array.isArray(authority)) auths = authority;
  else auths.push(authority);
  return localStorage.setItem('antd-pro-authority', JSON.stringify(auths));
}
