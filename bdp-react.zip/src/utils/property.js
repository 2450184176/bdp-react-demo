export const loginUrl = '/portal-web-system/usermanage/admin/system?url=/aip';
