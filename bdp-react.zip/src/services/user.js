// import { stringify } from 'qs';
import axios from '../utils/axios';

export async function getUserInfo() {
  return axios.get('/api/admin/getUser');
}
