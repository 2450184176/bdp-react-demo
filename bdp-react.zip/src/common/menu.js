import { isUrl } from '../utils/utils';

export const menuData = [
  {
    name: '测试页面',
    path: 'test',
    hideChildren: true,
    hideInMenu: true,
    children: [],
  },
  {
    name: '登录',
    path: 'login',
    redirect: 'sigin',
    hideChildren: true,
    hideInMenu: true,
    children: [
      {
        name: '用户登录',
        // icon: 'upload-file',
        path: 'sigin',
        // authority: 'super_admin',
      },
      {
        name: '找回密码',
        path: 'find-password',
      },
    ],
  },
  {
    name: '我的大数据',
    path: 'mybdp',
    redirect: 'console',
    // authority: ['login'],
    children: [
      {
        name: '工作台',
        path: 'console',
      },
      {
        name: '项目中心',
        path: 'project-center',
        hideChildren: true,
        children: [
          {
            name: '项目详情',
            path: 'project-detail',
            children: [
              {
                name: '角色权限管理',
                path: 'role-manage',
              },
            ],
          },
        ],
      },
      {
        name: '流程中心',
        path: 'process-center',
        hideChildren: true,
        children: [
          {
            name: '流程详情',
            path: 'process-detail',
          },
        ],
      },
      {
        name: '资源中心',
        path: 'resource-center',
      },
      {
        name: '数据源',
        path: 'data-source',
      },
      {
        name: '平台管理',
        path: 'platform-manage',
        hideChildren: true,
        children: [
          {
            name: '部门管理',
            path: 'department-manage',
          },
          {
            name: '权限管理',
            path: 'power-manage',
            redirect: 'user',
            children: [
              {
                name: '用户管理',
                path: 'user',
              },
              {
                name: '角色管理',
                path: 'role',
              },
              {
                name: '权限管理',
                path: 'power',
              },
            ],
          },
          {
            name: '系统管理',
            path: 'system-manage',
            redirect: 'engin',
            children: [
              {
                name: '引擎',
                path: 'engin',
              },
              {
                name: '虚节点',
                path: 'vnodes',
              },
              {
                name: '发布消息',
                path: 'notify',
              },
              {
                name: '流程模版',
                path: 'process-template',
              },
              {
                name: 'IDE集群配置',
                path: 'ide-config',
                hideChildren: true,
                children: [
                  {
                    name: '编辑',
                    path: 'ide-config-edite',
                  },
                ],
              },
            ],
          },
          {
            name: '资源管理',
            path: 'resouce-manage',
            redirect: 'db-manage',
            children: [
              {
                name: '数据库资源管理',
                path: 'db-manage',
              },
              {
                name: '资源预算配置',
                path: 'budget-config',
              },
            ],
          },
        ],
      },
      {
        name: '个人中心',
        path: 'mine',
        hideInMenu: true,
        hideChildren: true,
        children: [
          {
            name: '个人资料',
            path: 'my-resouce',
            icon: 'user',
          },
          {
            name: '修改密码',
            path: 'change-password',
            icon: 'lock',
          },
        ],
      },
    ],
  },
  {
    name: '调度服务',
    path: 'sch',
    children: [
      {
        name: '调度管理',
        path: 'tasks',
      },
      {
        name: '调度实例',
        path: 'jobs',
      },
      {
        name: '参数配置',
        path: 'params',
      },
      {
        name: '文件管理',
        path: 'resource',
      },
      {
        name: '回收箱',
        path: 'rubbish',
        hideInMenu: true,
      },
    ],
  },
  {
    name: '异常页',
    icon: 'warning',
    path: 'exception',
    hideInMenu: true,
    children: [
      {
        name: '401',
        path: '401',
      },
      {
        name: '403',
        path: '403',
      },
      {
        name: '404',
        path: '404',
      },
      {
        name: '500',
        path: '500',
      },
    ],
  },
];

function formatter(data, parentPath = '/', parentAuthority) {
  return data.map(item => {
    let { path, redirect } = item;
    if (!isUrl(path)) {
      path = parentPath + item.path;
    }
    if (redirect && !isUrl(redirect)) {
      redirect = `${path}/${redirect}`;
    }
    const result = {
      ...item,
      path,
      redirect,
      exact: true,
      authority: item.authority || parentAuthority,
    };
    if (item.children) {
      result.children = formatter(item.children, `${parentPath}${item.path}/`, item.authority);
    }
    return result;
  });
}

export const getMenuData = () => formatter(menuData);
