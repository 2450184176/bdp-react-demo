import { message } from 'antd';
import { getUserInfo } from '../services/user';
import { setAuthority } from '../utils/authority';

export default {
  namespace: 'user',

  state: {
    currentUser: {
      id: '000001',
    },
    userApps: [],
    noticeNum: 0,
  },

  effects: {
    *getCurrentUser(_, { call }) {
      let currentUser = yield call(getUserInfo);
      currentUser = currentUser || { id: '000001', name: 'xxxx' };
      if (!currentUser) {
        message.error('用户信息获取失败');
        return false;
      }
      currentUser.role = 'user';
      if (currentUser.role) {
        yield setAuthority(currentUser.role);
      } else {
        yield (window.location.href = '/#/exception/403');
      }
      return true;
    },
  },

  reducers: {
    update(state, { payload }) {
      return {
        ...state,
        ...payload,
      };
    },
  },
};
