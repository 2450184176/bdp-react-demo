import React, { PureComponent } from 'react';
import { Menu, Icon, Spin, Dropdown, Layout } from 'antd';
import { Link } from 'dva/router';
import BdpIcon from '@/components/Bdp/BdpIcon';
import { menuData } from '@/common/menu';
import './index.less';

const { Header } = Layout;

export default class GlobalHeader extends PureComponent {
  state = {};

  componentDidMount() {}

  render() {
    const {
      currentUser: { name: userName },
      onMenuClick,
      fullScreen = false,
      noticeNum = 0,
    } = this.props;
    const menu = (
      <Menu className="aiheader-login-menu" selectedKeys={[]} onClick={onMenuClick}>
        <Menu.Item key="logout">
          <Icon type="logout" />
          退出
        </Menu.Item>
      </Menu>
    );
    return (
      <Header className={fullScreen ? 'aiheader-full-screen' : ''}>
        <div className="aiheader-wrap">
          <div className="aiheader-brand">
            <Link to="/" className="aiheader-brand-logo" key="logo">
              <BdpIcon type="logo-white" color="#ffffff" />
            </Link>
            <Link to="/">
              <p>机器学习</p>
            </Link>
          </div>
          <div className="aiheader-nav">
            {menuData.map(mainItem =>
              mainItem.hideInMenu ? (
                ''
              ) : (
                <a key={mainItem.path} href={`#/${mainItem.path}`}>
                  {mainItem.name}
                </a>
              )
            )}
          </div>
          <div className="aiheader-content">
            <a href="http://10.117.176.210:8181/docs/aip" title="帮助">
              <BdpIcon type="help" />
            </a>
            <a href="/proc/#/messageCenter" title="消息">
              <BdpIcon type="message" />
              <b className="aiheader-msg-num">{noticeNum > 99 ? '99+' : noticeNum}</b>
            </a>
          </div>
          <div className="aiheader-right">
            {userName ? (
              <div>
                <span className="aiheader-account">
                  <span>{userName}</span>
                </span>
                <Dropdown overlay={menu}>
                  <span className="aiheader-action">
                    退出登录
                    <BdpIcon type="dir-down" />
                  </span>
                </Dropdown>
              </div>
            ) : (
              <Spin size="small" style={{ marginLeft: 8 }} />
            )}
          </div>
        </div>
      </Header>
    );
  }
}
