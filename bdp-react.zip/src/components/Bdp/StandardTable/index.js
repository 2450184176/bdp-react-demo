import React, { PureComponent } from 'react';
import { Table } from 'antd';
import { connect } from 'dva';
import styles from './index.less';

function initTotalList(columns) {
  const totalList = [];
  columns.forEach(column => {
    if (column.needTotal) {
      totalList.push({ ...column, total: 0 });
    }
  });
  return totalList;
}
@connect(({ modelDetail }) => ({
  modelDetail,
}))
class StandardTable extends PureComponent {
  constructor(props) {
    super(props);
    const { columns } = props;
    const needTotalList = initTotalList(columns);

    this.state = {
      selectedRowKeys: [],
      needTotalList,
      activeIndex: '',
    };
  }

  componentWillReceiveProps(nextProps) {
    // clean state
    if (nextProps.selectedRows && nextProps.selectedRows.length === 0) {
      const needTotalList = initTotalList(nextProps.columns);
      this.setState({
        selectedRowKeys: [],
        needTotalList,
      });
    }
  }

  handleRowSelectChange = (selectedRowKeys, selectedRows) => {
    let needTotalList = [...this.state.needTotalList];
    needTotalList = needTotalList.map(item => ({
      ...item,
      total: selectedRows.reduce((sum, val) => sum + parseFloat(val[item.dataIndex], 10), 0),
    }));

    if (this.props.onSelectRow) {
      this.props.onSelectRow(selectedRows);
    }

    this.setState({ selectedRowKeys, needTotalList });
  };

  handleTableChange = (pagination, filters, sorter) => {
    this.props.onChange(pagination, filters, sorter);
  };

  cleanSelectedKeys = () => {
    this.handleRowSelectChange([], []);
  };

  setClassName = (record, index) => {
    const { activeIndex } = this.state;
    return index === activeIndex ? `${styles.tableRowActive}` : '';
  };

  singleClick = (i, edata) => {
    this.setState({ activeIndex: i });
    const { dispatch } = this.props;
    dispatch({ type: 'modelDetail/saveRow', rowData: edata });
  };

  dbClick = (i, edata) => {
    const { dispatch } = this.props;
    dispatch({ type: 'modelDetail/changeEdit', reEdit: edata.rowKey });
  };

  render() {
    const { selectedRowKeys, selectedRows } = this.state;
    const { scroll, noPageNation } = this.props;
    const {
      data: { list, pagination },
      loading,
      columns,
      rowKey,
    } = this.props;
    // eslint-disable-next-line
    const paginationProps = {
      showSizeChanger: true,
      showQuickJumper: true,
      ...pagination,
    };

    const rowSelection = {
      selectedRowKeys,
      onChange: this.handleRowSelectChange,
      getCheckboxProps: record => ({
        disabled: record.disabled,
      }),
    };

    return (
      <div className={styles.standardTable}>
        <Table
          loading={loading}
          rowKey={record => (rowKey ? record[rowKey] : record.key)}
          rowSelection={selectedRows ? rowSelection : null}
          dataSource={list}
          columns={columns}
          scroll={scroll}
          pagination={noPageNation ? false : { paginationProps }} //  pagination={paginationProps}
          onChange={this.handleTableChange}
          size="small"
          rowClassName={this.setClassName}
          onRow={(record, index) => ({
            onClick: () => {
              this.singleClick(index, record);
            },
            onDoubleClick: () => {
              this.dbClick(index, record);
            },
          })}
        />
      </div>
    );
  }
}

export default StandardTable;
