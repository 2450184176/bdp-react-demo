import React from 'react';

function PngShow(props){
  const { url,type } = props;
  return (
    <a className="bdp-png-show" href={url} rel="noopener noreferrer" target="_blank">
      {type && type ==='img' && <img src={url} alt="pic" />}
      {!type&&<span>{url.substring(url.lastIndexOf('/')+1)}</span>}
    </a>
  )
}

export default PngShow;
