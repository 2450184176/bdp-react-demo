import React from 'react';
import PropTypes from 'prop-types';
import { Layout, Spin } from 'antd';
import DocumentTitle from 'react-document-title';
import { connect } from 'dva';
import { Route, Redirect, Switch } from 'dva/router';
import { ContainerQuery } from 'react-container-query';
import classNames from 'classnames';
import NotFound from '../routes/Exception/404';
import { getRoutes } from '../utils/utils';

import Authorized from '../utils/Authorized';
import { getMenuData } from '../common/menu';
import './basicLayout.less';

const { Content } = Layout;
const { AuthorizedRoute, check } = Authorized;

/**
 * 根据菜单取得重定向地址.
 */
const redirectData = [];
const getRedirect = item => {
  const { redirect, children, path } = item || {};
  if (!path || !Array.isArray(children) || children.length === 0) return;
  if (redirect) {
    redirectData.push({
      from: path,
      to: redirect,
    });
  }
  children.map(c => {
    getRedirect(c);
    return 1;
  });
  // if (item && item.children) {
  //   if (item.children[0] && item.children[0].path) {
  //     redirectData.push({
  //       from: `${item.path}`,
  //       to: `${item.children[0].path}`,
  //     });
  //     item.children.forEach(children => {
  //       getRedirect(children);
  //     });
  //   }
  // }
};
getMenuData().forEach(menu => {
  getRedirect(menu);
});

const query = {
  'screen-xs': {
    maxWidth: 575,
  },
  'screen-sm': {
    minWidth: 576,
    maxWidth: 767,
  },
  'screen-md': {
    minWidth: 768,
    maxWidth: 991,
  },
  'screen-lg': {
    minWidth: 992,
    maxWidth: 1199,
  },
  'screen-xl': {
    minWidth: 1200,
  },
};

@connect(({ global }) => ({
  collapsed: global.collapsed,
  globalLoading: global.globalLoading,
  loadingTip: global.loadingTip,
  fullScreen: global.fullScreen,
}))
class BasicLayout extends React.PureComponent {
  static childContextTypes = {
    location: PropTypes.object,
    breadcrumbNameMap: PropTypes.object,
  };

  getChildContext() {
    const { location, routerData } = this.props;
    return {
      location,
      breadcrumbNameMap: routerData,
    };
  }

  componentWillMount() {}

  getPageTitle = () => {
    const { routerData, location } = this.props;
    const { pathname } = location;
    let title = '大数据平台';
    if (routerData[pathname] && routerData[pathname].name) {
      title = `${routerData[pathname].name} - 大数据平台`;
    }
    return title;
  };

  getBashRedirect = () => {
    // According to the url parameter to redirect
    // 这里是重定向的,重定向到 url 的 redirect 参数所示地址
    const urlParams = new URL(window.location.href);
    const redirect = urlParams.searchParams.get('redirect');
    // Remove the parameters in the url
    if (redirect) {
      urlParams.searchParams.delete('redirect');
      window.history.replaceState(null, 'redirect', urlParams.href);
    } else {
      const { routerData } = this.props;
      // get the first authorized route path in routerData
      const authorizedPath = Object.keys(routerData).find(
        item => check(routerData[item].authority, item) && item !== '/'
      );
      return authorizedPath;
    }
    return redirect;
  };

  render() {
    const { routerData, match, globalLoading, loadingTip } = this.props;
    const bashRedirect = this.getBashRedirect();
    const routes = getRoutes(match.path, routerData);

    const layout = (
      <Spin spinning={globalLoading} delay={500} tip={loadingTip}>
        <Layout className="ai-main-layout">
          <Layout>
            <Content className="ai-main-content">
              <Switch>
                {redirectData.map(item => (
                  <Redirect key={item.from} exact from={item.from} to={item.to} />
                ))}
                {routes.map(item => (
                  <AuthorizedRoute
                    key={item.key}
                    path={item.path}
                    component={item.component}
                    exact={item.exact}
                    authority={item.authority}
                    redirectPath="/exception/403"
                  />
                ))}
                <Redirect exact from="/" to={bashRedirect} />
                <Route render={NotFound} />
              </Switch>
            </Content>
          </Layout>
        </Layout>
      </Spin>
    );
    return (
      <DocumentTitle title={this.getPageTitle()}>
        <ContainerQuery query={query}>
          {params => <div className={classNames(params)}>{layout}</div>}
        </ContainerQuery>
      </DocumentTitle>
    );
  }
}

export default BasicLayout;
