import React from 'react';

/* eslint-disable */
class FindPassword extends React.PureComponent {
  render() {
    return <div>FindPassword 加紧施工中。。。</div>;
  }
}

export default FindPassword;
