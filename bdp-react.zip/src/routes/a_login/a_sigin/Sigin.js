import React from 'react';

/* eslint-disable */
class Sigin extends React.PureComponent {
  render() {
    return <div>Sigin 加紧施工中。。。</div>;
  }
}

export default Sigin;
