import React from 'react';
import { getMenuData } from '@/common/menu';
import { Link } from 'dva/router';

/* eslint-disable */
class Test extends React.PureComponent {
  state = {
    routers: [],
  };

  componentDidMount() {
    const routers = this.getNodes(getMenuData());
    this.setState({ routers });
  }

  getNodes = menu => {
    let nodes = [];
    if (Array.isArray(menu)) {
      nodes = [].concat(...menu.map(m => this.getNodes(m)));
    } else if (menu) {
      nodes = [menu];
      if (menu.children) {
        nodes = [...nodes, ...[].concat(...menu.children.map(c => this.getNodes(c)))];
      }
    }
    return nodes;
  };

  render() {
    const { routers } = this.state;
    return (
      <div>
        {(routers || []).map((route, index) => (
          <div key={route.path}>
            <Link to={route.path} target="_blank">
              {route.name}
            </Link>
          </div>
        ))}
      </div>
    );
  }
}

export default Test;
