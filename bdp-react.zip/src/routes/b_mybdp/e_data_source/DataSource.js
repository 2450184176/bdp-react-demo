import React from 'react';

/* eslint-disable */
class DataSource extends React.PureComponent {
  render() {
    return <div>DataSource 加紧施工中。。。</div>;
  }
}

export default DataSource;
