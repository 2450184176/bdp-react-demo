import React from 'react';

/* eslint-disable */
class ProcessDetail extends React.PureComponent {
  render() {
    return <div>ProcessDetail 加紧施工中。。。</div>;
  }
}

export default ProcessDetail;
