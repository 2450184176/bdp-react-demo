import React from 'react';

/* eslint-disable */
class ProcessCenter extends React.PureComponent {
  render() {
    return <div>ProcessCenter 加紧施工中。。。</div>;
  }
}

export default ProcessCenter;
