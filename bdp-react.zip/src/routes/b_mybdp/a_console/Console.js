import React from 'react';

/* eslint-disable */
class Console extends React.PureComponent {
  render() {
    return <div>Console 加紧施工中。。。</div>;
  }
}

export default Console;
