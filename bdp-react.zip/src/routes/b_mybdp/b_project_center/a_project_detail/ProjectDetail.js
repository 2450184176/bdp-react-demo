import React from 'react';

/* eslint-disable */
class ProjectDetail extends React.PureComponent {
  render() {
    return <div>ProjectDetail 加紧施工中。。。</div>;
  }
}

export default ProjectDetail;
