import React from 'react';

/* eslint-disable */
class RoleManage extends React.PureComponent {
  render() {
    return <div>RoleManage 加紧施工中。。。</div>;
  }
}

export default RoleManage;
