import React from 'react';

/* eslint-disable */
class ProjectCenter extends React.PureComponent {
  render() {
    return <div>ProjectCenter 加紧施工中。。。</div>;
  }
}

export default ProjectCenter;
