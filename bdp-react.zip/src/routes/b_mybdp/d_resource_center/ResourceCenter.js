import React from 'react';

/* eslint-disable */
class ResourceCenter extends React.PureComponent {
  render() {
    return <div>ResourceCenter 加紧施工中。。。</div>;
  }
}

export default ResourceCenter;
