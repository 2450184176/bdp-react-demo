import React from 'react';

/* eslint-disable */
class Mine extends React.PureComponent {
  render() {
    return <div>Mine 加紧施工中。。。</div>;
  }
}

export default Mine;
