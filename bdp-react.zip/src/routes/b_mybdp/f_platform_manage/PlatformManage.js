import React from 'react';

/* eslint-disable */
class PlatformManage extends React.PureComponent {
  render() {
    return <div>PlatformManage 加紧施工中。。。</div>;
  }
}

export default PlatformManage;
