import React from 'react';

/* eslint-disable */
class Vnodes extends React.PureComponent {
  render() {
    return <div>Vnodes 加紧施工中。。。</div>;
  }
}

export default Vnodes;
