import React from 'react';

/* eslint-disable */
class IdeConfig extends React.PureComponent {
  render() {
    return <div>IdeConfig 加紧施工中。。。</div>;
  }
}

export default IdeConfig;
