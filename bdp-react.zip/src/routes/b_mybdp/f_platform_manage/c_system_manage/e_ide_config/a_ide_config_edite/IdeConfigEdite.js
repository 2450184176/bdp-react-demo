import React from 'react';

/* eslint-disable */
class IdeConfigEdite extends React.PureComponent {
  render() {
    return <div>IdeConfigEdite 加紧施工中。。。</div>;
  }
}

export default IdeConfigEdite;
