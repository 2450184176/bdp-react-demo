import React from 'react';

/* eslint-disable */
class ProcessTemplate extends React.PureComponent {
  render() {
    return <div>ProcessTemplate 加紧施工中。。。</div>;
  }
}

export default ProcessTemplate;
