import React from 'react';

/* eslint-disable */
class Notify extends React.PureComponent {
  render() {
    return <div>Notify 加紧施工中。。。</div>;
  }
}

export default Notify;
