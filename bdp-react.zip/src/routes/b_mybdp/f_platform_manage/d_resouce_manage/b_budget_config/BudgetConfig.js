import React from 'react';

/* eslint-disable */
class BudgetConfig extends React.PureComponent {
  render() {
    return <div>BudgetConfig 加紧施工中。。。</div>;
  }
}

export default BudgetConfig;
