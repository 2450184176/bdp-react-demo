import React from 'react';

/* eslint-disable */
class DbManage extends React.PureComponent {
  render() {
    return <div>DbManage 加紧施工中。。。</div>;
  }
}

export default DbManage;
