import React from 'react';

/* eslint-disable */
class Role extends React.PureComponent {
  render() {
    return <div>Role 加紧施工中。。。</div>;
  }
}

export default Role;
