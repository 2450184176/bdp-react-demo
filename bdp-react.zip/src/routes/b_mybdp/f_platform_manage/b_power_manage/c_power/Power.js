import React from 'react';

/* eslint-disable */
class Power extends React.PureComponent {
  render() {
    return <div>Power 加紧施工中。。。</div>;
  }
}

export default Power;
