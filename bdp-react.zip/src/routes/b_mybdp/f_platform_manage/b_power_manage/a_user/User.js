import React from 'react';

/* eslint-disable */
class User extends React.PureComponent {
  render() {
    return <div>User 加紧施工中。。。</div>;
  }
}

export default User;
