import React from 'react';

/* eslint-disable */
class DepartmentManage extends React.PureComponent {
  render() {
    return <div>DepartmentManage 加紧施工中。。。</div>;
  }
}

export default DepartmentManage;
