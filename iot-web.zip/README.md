# 物联网平台

### 前端架构
>vue2.5.16（vue-router、axios、vuex、）+elementUI2.4.8

### axios
>集成http.js(axios拦截器) 实现统一登录，统一出错处理;

### vue-router
>集成vue-router(实现权限路由钩子);

### vuex
>集成vuex 全局状态管理（模块global处理全局状态);

>namespaced: true 激活模块命名空间;

> action(所有异步改变通过commit| mutation 改变 state), mutation 改变 state, state ->激活页面变化

>mapGetters,mapState,mapMutations,mapActions(使用方法在App.vue)

## 一期迭代内容
>1、物联网主页，包含设备在线，产品种类

>2、产品列表，消息上行、下行数，规则命中、规则状发数

>3、产品详情，产品信息，设备列表，消息通信，服务端订阅，日志服务

>4、设备列表，设备详情，设备信息，Topic列表，设备影子

>5、规则引擎列表，规则详情，添加详情，删除详情，编辑和测试sql

>6、OTA升级服务，包括创建升级包和升级任务

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```
