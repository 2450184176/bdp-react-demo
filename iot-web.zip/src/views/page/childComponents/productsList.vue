<template>
  <div>
    <div class="proListHead animated fadeIn">
      <el-form :inline="true">
        <el-form-item label="产品名称：">
          <el-input v-model="productName" placeholder="请输入产品名称" clearable @keyup.enter.native="onSearch" ref="input"/>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" size="medium" @click="onSearch">搜索</el-button>
        </el-form-item>
        <el-form-item>
          <el-button type="success" size="medium" @click="showForm('addForm')">新建产品</el-button>
        </el-form-item>
        <el-form-item>
          <el-button type="warning" class="switchBtn" size="medium" @click="switchShow === 'card' ? switchShow = 'table' : switchShow = 'card'">切换视图</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="proListContent">
      <div class="item animated fadeIn" v-for="item in proLists" :key="item.productId" v-show="switchShow==='card'">
        <div class="itemLeft">
          <div class="first">
            <span class="title" @click="handleClick('detail', item)">{{item.productName}}</span>
            <el-tag size="small" v-for="one in item.labels" :key="one.id">
              {{one.labelValue}}
            </el-tag>
          </div>
          <div class="second">
            <span>产品Key：{{item.productKey}}</span>
            <span>协议类型：{{item.protocolType}}</span>
            <span><i class="fa fa-circle"></i>在线设备数：{{item.online}}</span>
            <span><i class="fa fa-circle"></i>离线设备数：{{item.offline}}</span>
          </div>
          <div class="third">
            <span>创建时间：{{item.creatTime}}</span>
            <span>最后编辑时间：{{item.lastModifyTime}}</span>
          </div>
          <div class="five">
            描述： {{item.remark}}
          </div>
        </div>
        <div class="itemRight">
          <div><el-button type="text" @click="handleClick('delete', item)">删除</el-button></div>
        </div>
      </div>
      <el-table class="animated fadeIn" v-show="switchShow==='table'" :data="proLists" stripe v-loading="productLoading" element-loading-text="数据加载中...">
        <el-table-column align="center" type="index" label="#" />
        <el-table-column align="center" show-overflow-tooltip prop="productName" label="产品名称">
          <template slot-scope="scope">
            <el-button @click="handleClick('detail', scope.row)" type="text" size="small">{{scope.row.productName}}</el-button>
          </template>
        </el-table-column>
        <el-table-column align="center" show-overflow-tooltip prop="productKey" label="产品Key" />
        <el-table-column align="center" show-overflow-tooltip prop="protocolType" label="产品协议" />
        <el-table-column align="center" prop="online" label="在线设备数" />
        <el-table-column align="center" prop="offline" label="离线设备数" />
        <el-table-column align="center" show-overflow-tooltip prop="creatTime" label="创建时间" />
        <el-table-column align="center" show-overflow-tooltip prop="lastModifyTime" label="最后修改时间" />
        <el-table-column align="center" label="操作" width="110">
          <template slot-scope="scope">
            <el-button size="mini" type="text" @click="handleClick('detail', scope.row)">详情</el-button>
            <el-button size="mini" type="text" @click="handleClick('delete', scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div align="right" style="margin-top: 15px">
        <el-pagination
                @size-change="sizeChange"
                @current-change="pageChange"
                :current-page="pageNum"
                :page-size="pageSize"
                :page-sizes="[10, 20, 40, 100]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="新建产品" :visible.sync="addProVisible" width="40%">
      <el-form :model="form" :rules="addRule" ref="addForm">
        <el-form-item label="产品名称：" :label-width="'120px'" required prop="productName">
          <el-input v-model="form.productName" placeholder="请输入产品名称"/>
        </el-form-item>
        <el-form-item label="产品类型：" :label-width="'120px'" required prop="productType">
          <el-radio-group v-model="form.productType">
            <el-radio label="1">设备</el-radio>
            <el-radio label="2">网关</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="协议类型：" :label-width="'120px'" required prop="protocolType">
          <el-select filterable clearable v-model="form.protocolType" placeholder="请选择">
            <el-option label="MQTT" value="MQTT" />
            <el-option label="TCP" value="TCP" />
            <el-option label="UDP" value="UDP" />
            <el-option label="HTTP" value="HTTP" />
          </el-select>
        </el-form-item>
        <el-form-item v-if="form.protocolType==='HTTP'" label="产品KEY：" :label-width="'120px'" required prop="productKey">
          <el-input placeholder="请输入产品KEY" v-model="form.productKey"/>
        </el-form-item>
        <el-form-item v-if="form.protocolType==='MQTT'" label="是否透传：" :label-width="'120px'" required prop="transparent">
          <el-radio-group v-model="form.transparent">
            <el-radio label="1">是</el-radio>
            <el-radio label="2">否</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="第二责任人：" :label-width="'120px'" prop="userIds">
          <el-select
                  :multiple-limit="10"
                  v-model="form.userIds"
                  multiple
                  filterable
                  remote
                  default-first-option
                  reserve-keyword
                  :remote-method="searchUser"
                  placeholder="请输入工号">
            <el-option
                    v-for="item in authPeoples"
                    :key="item.name"
                    :label="item.id+'-'+item.name"
                    :value="item.id+'-'+item.name">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="产品备注：" :label-width="'120px'" required prop="remark">
          <el-input type="textarea" :rows="2" placeholder="请输入内容" v-model="form.remark"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addProVisible = false">取 消</el-button>
        <el-button type="primary" @click="sureSubmit('addForm')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapActions } from 'vuex';

export default {
  name: 'productsList',
  data() {
    const proNameReg = (rule, value, callback) => {
      const regRule = /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/.test(value);
      const spaceReg = /\s+/g.test(value);
      const specialWord = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>《》/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？ ]");
      if (regRule) {
        const len = value.replace(/[\u4e00-\u9fa5]/g, 'aa').length;
        if (len < 4 || len > 60) { callback(new Error('支持中文、字母、数字、下划线，长度在4-60位.')); }
      }
      if (value === '' || spaceReg) { callback(new Error('产品名称不能为空、不能有空格！')); }
      if (specialWord.test(value)) { callback(new Error('产品名称不能包含！@#￥%……&*（）等特殊字符！')); }
      callback();
    };
    const productKeyReg = (rule, value, callback) => {
      const regRule = /^[a-zA-Z0-9_]{1,50}$/.test(value);
      if (!regRule) {
        callback(new Error('产品Key支持数字字母下划线，长度在1-50位！'));
      }
      callback();
    };
    const remarkReg = (rule, value, callback) => {
      const regRule = /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/.test(value);
      const spaceReg = /\s+/g.test(value);
      if (regRule) {
        const len = value.replace(/[\u4e00-\u9fa5]/g, 'aa').length;
        if (len < 1 || len > 100) { callback(new Error('不能为空，且长度在1-100.')); }
      }
      if (value === '' || spaceReg) { callback(new Error('产品备注不能为空、不能有空格！')); }
      callback();
    };
    return {
      productName: '',
      proLists: [],
      totalCount: 0,
      pageNum: 1,
      pageSize: 10,
      productLoading: false,
      selectRow: {},
      switchShow: 'table',
      addProVisible: false,
      form: {
        productName: '',
        productType: '',
        protocolType: '',
        productKey: '',
        transparent: '',
        userIds: '',
        remark: '',
      },
      authPeoples: [],
      addRule: {
        productName: [
          { required: true, validator: proNameReg },
        ],
        productType: [
          { required: true, message: '请选择产品类型', trigger: 'blur' },
        ],
        protocolType: [
          { required: true, message: '请选择协议类型', trigger: 'blur' },
        ],
        productKey: [
          { required: true, validator: productKeyReg },
        ],
        remark: [
          { required: true, validator: remarkReg },
        ],
        transparent: [
          { required: true, message: '请选择是否透传', trigger: 'blur' },
        ],
      },
    };
  },
  methods: {
    ...mapActions([
      'getAllProducts',
    ]),
    searchUser(userId) { this.traffic.searchUsers(this, userId); },
    async getProList(page, size, txt) {
      this.productLoading = true;
      const res = await this.$Fetch.productList({ pageNum: page, pageSize: size, keyWords: txt });
      this.productLoading = false;
      if (res) {
        this.proLists = res.result;
        this.totalCount = res.total;
      }
    },
    sizeChange(xSize) { this.getProList(this.pageNum, xSize, this.productName); },
    pageChange(yNum) { this.getProList(yNum, this.pageSize, this.productName); },
    onSearch() {
      // eslint-disable-next-line
      this.$refs['input'].focus();
      this.getProList(this.pageNum, this.pageSize, this.productName);
    },
    showForm(formName) {
      this.addProVisible = true;
      this.$nextTick(() => { this.$refs[formName].resetFields(); });
    },
    sureSubmit(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          const res = await this.$Fetch.addPro(this.form);
          if (res) {
            this.getAllProducts();
            this.$message.success(res);
            this.getProList(this.pageNum, this.pageSize, this.productName);
            this.addProVisible = false;
          }
        }
      });
    },
    async handleClick(choose, row) {
      const params = { id: row.id };
      await this.$store.commit('setProId', row.id);
      if (choose === 'detail') {
        this.$router.push({ path: '/ProductDetail/ProInfo', query: { productId: params.id } });
      }
      if (choose === 'delete') {
        if (row.online + row.offline > 0) {
          this.$alert(`该产品中有${row.online + row.offline}台设备，请先删除已添加的设备后再删除改产品！`, '提示', {
            confirmButtonText: '确定',
            type: 'warning',
            callback: () => {},
          });
          return;
        }
        this.$confirm('此操作将永久删除该产品, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(async () => {
          const res = await this.$Fetch.deletePro(params);
          if (res) {
            this.getAllProducts();
            this.getProList(this.pageNum, this.pageSize, this.productName);
            this.$message.success('删除成功!');
          }
        }).catch(() => {});
      }
    },
  },
  created() {
    this.getProList(this.pageNum, this.pageSize, this.productName);
  },
};
</script>
