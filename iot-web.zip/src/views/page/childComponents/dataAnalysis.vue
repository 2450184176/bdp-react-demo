<template>
  <div class="proDetail animated fadeIn">
    功能开发中。。。
  </div>
</template>

<script>
export default {
  name: 'dataAnalysis',
  data() {
    return {};
  },
  methods: {},
  created() {
  },
  mounted() {},
  computed: {},
};
</script>
