<template>
  <div>
    <div class="proDetail animated fadeIn">
      <el-radio-group v-model="upKind" size="medium"  @change="switchPath" >
        <el-radio-button label="升级包"/>
        <el-radio-button label="升级任务"/>
      </el-radio-group>
    </div>
    <div class="proDetail">
      <router-view/>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'edgeManage',
  data() {
    return {
      upKind: '',
    };
  },
  methods: {
    switchPath(v) {
      if (v === '升级包') { this.$router.push({ path: '/EdgeManage/upPackage' }); }
      if (v === '升级任务') { this.$router.push({ path: '/EdgeManage/taskManage' }); }
    },
  },
  created() {
    this.upKind = this.getUpKind;
  },
  computed: {
    ...mapGetters([
      'getUpKind',
    ]),
  },
};
</script>
