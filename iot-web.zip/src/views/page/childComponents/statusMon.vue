<template>
  <div class="animated fadeIn">
    <div class="sameCss">
      <appChart/>
    </div>
    <div class="sameCss">
      <gatherChart/>
    </div>
    <div class="sameCss">
      <relayChart/>
    </div>
  </div>
</template>

<script>
import appChart from '../../commonComponents/homeComponents/appChart';
import gatherChart from '../../commonComponents/homeComponents/gatherChart';
import relayChart from '../../commonComponents/homeComponents/relayChart';

export default {
  name: 'statusMon',
  data() {
    return {};
  },
  methods: {},
  components: {
    appChart,
    gatherChart,
    relayChart,
  },
  created() {
  },
  mounted() {},
  computed: {},
};
</script>
