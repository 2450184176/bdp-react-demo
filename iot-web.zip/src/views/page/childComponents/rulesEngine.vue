<template>
  <div>
    <div class="rulesHead animated fadeIn">
      <el-form :inline="true">
        <el-form-item label="输入规则名称：">
          <el-input v-model="rulesName" clearable @keyup.enter.native="loadRules" placeholder="请输入规则名称"/>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" size="medium" @click="loadRules">搜索</el-button>
        </el-form-item>
        <el-form-item>
          <el-button type="success" size="medium" @click="showForm">新增规则</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div class="rulesContent">
      <el-table
              :data="ruleLists"
              stripe
              highlight-current-row
              v-loading="ruleLoading"
              element-loading-text="数据加载中...">
        <el-table-column type="index" label="#" />
        <el-table-column align="center" show-overflow-tooltip label="规则名称">
          <template slot-scope="scope">
            <el-button @click="handleClick(scope.row, 'detail')" type="text" size="small">{{scope.row.ruleName}}</el-button>
          </template>
        </el-table-column>
        <el-table-column align="center" show-overflow-tooltip label="运行状态">
          <template slot-scope="scope">
            <span v-if="scope.row.runStatus===2">
              <span><i class="fa fa-circle" style="color: #67C23A;"></i>  运行中</span>
            </span>
            <span v-if="scope.row.runStatus===1">
              <span><i class="fa fa-circle" style="color: #F56C6C;"></i>  未运行</span>
            </span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="createTime" label="创建时间" />
        <el-table-column show-overflow-tooltip align="center" prop="remark" label="备注" />
        <el-table-column label="操作" width="140">
          <template slot-scope="scope">
            <el-button v-if="scope.row.runStatus===2" @click="handleClick(scope.row, 'manage')" type="text">停止</el-button>
            <el-button v-if="scope.row.runStatus===1" @click="handleClick(scope.row, 'manage')" type="text">启动</el-button>
            <el-button @click="handleClick(scope.row, 'detail')" type="text">详情</el-button>
            <el-button @click="handleClick(scope.row, 'delete')" type="text">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div align="right" style="margin-top: 15px">
        <el-pagination
                @size-change="sizeChange"
                @current-change="pageChange"
                :current-page="pageNum"
                :page-size="pageSize"
                :page-sizes="[10, 20, 40, 100]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="新增规则" :visible.sync="addRuleVisible" width="40%">
      <el-form :model="form" :rules="ruleRules" ref="ruleForm">
        <el-form-item label="规则名称：" :label-width="'120px'" prop="ruleName">
          <el-input v-model.trim="form.ruleName" placeholder="请输入规则名称" />
        </el-form-item>
        <el-form-item label="规则描述：" :label-width="'120px'" prop="remark">
          <el-input v-model.trim="form.remark" type="textarea" :rows="2" placeholder="请输入内容"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addRuleVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOneRule('ruleForm')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'rulesEngine',
  data() {
    const ruleReg = (rule, value, callback) => {
      const regRule = /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]+$/.test(value);
      const spaceReg = /\s+/g.test(value);
      if (regRule) {
        const len = value.replace(/[\u4e00-\u9fa5]/g, 'aa').length;
        if (len < 4 || len > 30) { callback(new Error('支持入中文、字母、数字、下划线，长度在4-30位.')); }
      }
      if (value === '' || spaceReg) { callback(new Error('规则名称不能为空、不能有空格！')); }
      callback();
    };
    const markReg = (rule, value, callback) => {
      const len = value.replace(/[\u4e00-\u9fa5]/g, 'aa').length;
      const spaceReg = /\s+/g.test(value);
      if (len < 1 || len > 100) {
        callback(new Error('不能为空，且长度在1-100.'));
      }
      if (value === '' || spaceReg) { callback(new Error('规则描述不能为空、不能有空格！')); }
      callback();
    };
    return {
      rulesName: '',
      addRuleVisible: false,
      form: {
        ruleName: '',
        remark: '',
      },
      ruleLists: [],
      ruleLoading: false,
      totalCount: 0,
      pageNum: 1,
      pageSize: 10,
      ruleRules: {
        ruleName: [{ required: true, validator: ruleReg }],
        remark: [{ required: true, validator: markReg }],
      },
    };
  },
  methods: {
    showForm() {
      this.addRuleVisible = true;
      this.$nextTick(() => { this.$refs.ruleForm.resetFields(); });
    },
    addOneRule(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          const res = await this.$Fetch.add1Rule(this.form);
          if (res) {
            this.$message.success(res);
            this.addRuleVisible = false;
            this.loadRules();
          }
        }
      });
    },
    async handleClick(row, fun) {
      if (fun === 'manage') {
        const str = row.runStatus === 2 ? '停止' : '启动';
        this.$confirm(`您将执行${str}操作，确定吗？`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(async () => {
          const res = await this.$Fetch.ruleStartOrStop({ id: row.id, runStatus: row.runStatus === 2 ? 1 : 2 });
          if (res) {
            this.$message.success(res);
            this.loadRules();
          }
        }).catch(() => {});
      }
      if (fun === 'delete') {
        if (row.runStatus === 2) {
          this.$msgbox.alert('规则运行中，请先停止。', '提示', {
            confirmButtonText: '确定',
            type: 'warning',
            callback: () => {},
          });
          return;
        }
        this.$confirm('此操作将永久删除该规则, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(async () => {
          const res = await this.$Fetch.delete1rule({ id: row.id });
          if (res) {
            this.$message.success(res);
            this.loadRules();
          }
        }).catch(() => {});
      }
      if (fun === 'detail') {
        this.$router.push({
          path: '/RuleDetail', name: 'ruleDetail', params: row, query: { ruleId: row.id },
        });
      }
    },
    async loadRules() {
      const params = { keyWords: this.rulesName, pageSize: this.pageSize, pageNum: this.pageNum };
      const res = await this.$Fetch.rulesList(params);
      if (res) {
        this.ruleLists = res.result;
        this.totalCount = res.total;
      }
    },
    sizeChange(size) { this.pageSize = size; this.loadRules(); },
    pageChange(num) { this.pageNum = num; this.loadRules(); },
  },
  created() {
    this.loadRules();
  },
  mounted() {},
  computed: {
    ...mapGetters([]),
  },
};
</script>
