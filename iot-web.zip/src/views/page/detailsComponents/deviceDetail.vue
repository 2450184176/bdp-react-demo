<template>
  <div class="animated fadeIn">
    <div class="baseProDetail">
      <div class="title">
        {{getDeviceDetails.equipmentName}}
      </div>
      <div class="someDetail">
        <span class="productId">设备名称：{{getDeviceDetails.equipmentName}}</span>
        <span class="productSecret">
          设备秘钥：<span v-show="!show">{{getDeviceDetails.equipmentSecret}}</span><span v-show="show">******</span>
          <el-button size="mini" type="text" @click="switchShow">{{show ? '显示' : '隐藏'}}</el-button>
          <!--<el-button size="mini" type="text" @click="switchShow" v-show="!show">隐藏</el-button>-->
        </span>
        <span v-if="getDeviceDetails.runStatus===1">
          <span><i class="fa fa-circle" style="color: #67C23A;"></i>  在线</span>
        </span>
        <span v-if="getDeviceDetails.runStatus===2">
          <span><i class="fa fa-circle" style="color: #F56C6C;"></i>  离线</span>
        </span>
      </div>
      <div class="allDetail">
        <div :style="item.name===activeName ? 'color: #409EFF;' : ''" v-for="item in panes" :key="item.name" @click="tabClick(item)">
          <p>
            {{item.label}}
          </p>
          <div class="animated fadeInLeft" v-show="item.name===activeName" :style="item.name==='mesTel' ? 'width: 66px' : ''"></div>
        </div>
      </div>
    </div>
    <div>
      <router-view/>
    </div>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex';

export default {
  name: 'deviceDetail',
  data() {
    return {
      show: true,
      devStatus: '',
      activeName: 'devInfo',
      panes: [
        { label: '设备信息', name: 'devInfo' },
        { label: 'Topic列表', name: 'mesTel' },
        { label: '设备影子', name: 'devSha' },
      ],
    };
  },
  methods: {
    tabClick(tab) {
      const name = tab.name;
      this.activeName = name;
      const params = { deviceId: this.getDeviceId };
      switch (name) {
        case 'devInfo':
          this.$router.push({
            path: '/DeviceDetail/DevInfo', query: params,
          });
          break;
        case 'mesTel':
          this.$router.push({
            path: '/DeviceDetail/DevTel', query: params,
          });
          break;
        case 'devSha':
          this.$router.push({
            path: '/DeviceDetail/DevSha', query: params,
          });
          break;
        default:
          this.$router.push({
            path: '/DeviceDetail/DevInfo', query: params,
          });
      }
    },
    switchShow() { this.show = !this.show; },
    ...mapActions([
      'getDeviceDetail',
    ]),
    calActive(path) {
      if (path.endsWith('DevInfo')) {
        this.activeName = 'devInfo';
      } else if (path.endsWith('DevTel')) {
        this.activeName = 'mesTel';
      } else {
        this.activeName = 'devSha';
      }
    },
  },
  async created() {
    await this.getDeviceDetail(this.getDeviceId || this.$route.query.deviceId);
    this.calActive(this.$route.path);
  },
  mounted() {
  },
  computed: {
    ...mapGetters([
      'getProDetails',
      'getDeviceId',
      'getDeviceDetails',
    ]),
  },
};
</script>
