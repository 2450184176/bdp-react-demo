<template>
  <div>
    <div class="baseProDetail animated fadeIn">
      <div class="title">
        {{getProDetails.productName}}
      </div>
      <div class="someDetail">
        <span class="productId">产品KEY：{{getProDetails.productKey}}</span>
        <span class="productId">产品ID：{{getProDetails.id}}</span>
        <span class="productSecret">
          产品秘钥：<span v-show="!show">{{getProDetails.productSecret}}</span><span v-show="show">******</span>
          <el-button size="mini" type="text" @click="switchShow">{{show ? '显示' : '隐藏'}}</el-button>
        </span>
        <span>设备数：{{getProDetails.equipTotal}}</span>
      </div>
      <div class="allDetail">
        <div :style="item.name===activeName ? 'color: #409EFF;' : ''" v-for="item in panes" :key="item.name" @click="tabClick(item)">
          <p>
            {{item.label}}
          </p>
          <div class="animated fadeInLeft" v-show="item.name===activeName" :style="item.name==='ser' ? 'width: 69px' : ''"></div>
        </div>
      </div>
    </div>
    <div>
      <router-view/>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
  name: 'productsDetail',
  data() {
    return {
      show: true,
      activeName: 'pro',
      panes: [
        { label: '产品信息', name: 'pro' },
        { label: '设备列表', name: 'dev' },
        { label: '消息通信', name: 'inf' },
        { label: '服务端订阅', name: 'ser' },
        { label: '日志服务', name: 'log' },
      ],
      slideStyle: {},
    };
  },
  methods: {
    ...mapActions([
      'getProDetail',
    ]),
    tabClick(tab) {
      const name = tab.name;
      this.activeName = name;
      const params = { productId: this.getProDetails.id };
      switch (name) {
        case 'pro':
          this.$router.push({
            path: '/ProductDetail/ProInfo', query: params,
          });
          break;
        case 'dev':
          this.$router.push({
            path: '/ProductDetail/DeviceList', query: params,
          });
          break;
        case 'inf':
          this.$router.push({
            path: '/ProductDetail/InfoTel', query: params,
          });
          break;
        case 'ser':
          this.$router.push({
            path: '/ProductDetail/SerSub', query: params,
          });
          break;
        case 'log':
          this.$router.push({
            path: '/ProductDetail/LogSer', query: params,
          });
          break;
        default:
          this.$router.push({
            path: '/ProductDetail/ProInfo', query: params,
          });
      }
    },
    realPath(path) {
      if (path.endsWith('ProInfo')) { this.activeName = 'pro'; }
      if (path.endsWith('DeviceList')) { this.activeName = 'dev'; }
      if (path.endsWith('InfoTel')) { this.activeName = 'inf'; }
      if (path.endsWith('SerSub')) { this.activeName = 'ser'; }
      if (path.endsWith('LogSer')) { this.activeName = 'log'; }
    },
    switchShow() { this.show = !this.show; },
  },
  async created() {
    const breadData = this.getBread.third;
    if (breadData === '设备列表') this.activeName = 'dev';
    await this.getProDetail(this.$route.query.productId);
    await this.$store.commit('setProId', this.$route.query.productId);
    this.realPath(this.$route.path);
  },
  computed: {
    ...mapGetters([
      'getBread',
      'getProDetails',
    ]),
  },
};
</script>
