<template>
  <div class="animated fadeIn">
    <div class="proDetail">
      <h3>升级信息统计</h3>
      <div class="upStatistics">
        <div class="itemStat">
          <div>
            <p>{{details.lastTime}}</p>
            <p>测试耗时</p>
          </div>
          <div>
            <i class="fa fa-eye"></i>
          </div>
        </div>
        <div class="itemStat">
          <div>
            <p>{{details.upgradeTotal}}</p>
            <p>升级设备数（个）</p>
          </div>
          <div>
            <i class="fa fa-rocket"></i>
          </div>
        </div>
        <div class="itemStat">
          <div>
            <p style="color: #67C23A">{{details.upgradeTotal}}</p>
            <p>升级成功数（个）</p>
          </div>
          <div>
            <i class="fa fa-check"></i>
          </div>
        </div>
        <div class="itemStat">
          <div>
            <p style="color: #F56C6C">{{details.upgradeTotal - details.upgradeTotal}}</p>
            <p>升级失败数（个）</p>
          </div>
          <div>
            <i class="fa fa-exclamation"></i>
          </div>
        </div>
      </div>
    </div>
    <div class="proDetail">
      <h3>基本信息</h3>
      <div class="adjustCss">
        <div class="item_1">
          <div>
            <p>任务名称</p>
            <p>{{details.taskName}}</p>
          </div>
          <div>
            <p>升级方式</p>
            <p>{{details.upgradeWay | filToName}}</p>
          </div>
        </div>
        <div class="item_2">
          <div>
            <p>产品名称</p>
            <p>{{details.productName}}</p>
          </div>
          <div>
            <p>描述</p>
            <p>{{details.taskRemark}}</p>
          </div>
        </div>
        <div class="item_3">
          <div>
            <p>创建人</p>
            <p>{{details.creater}}</p>
          </div>
          <div>
            <p>创建时间</p>
            <p>{{details.createTime}}</p>
          </div>
        </div>
      </div>
    </div>
    <div class="proDetail">
      <h3>设备信息</h3>
      <el-table :data="deviceList" max-height="450" stripe v-loading="listLoading" element-loading-text="数据加载中...">
        <el-table-column align="center" type="index" label="#" />
        <el-table-column align="center" show-overflow-tooltip prop="equipmentName" label="设备名称"/>
        <el-table-column align="center" show-overflow-tooltip label="升级状态">
          <template slot-scope="scope">
            <span v-if="scope.row.upgradeStatus===1"><i class="fa fa-circle" style="color: #909399;"></i>  放弃升级</span>
            <span v-if="scope.row.upgradeStatus===2"><i class="fa fa-circle" style="color: #409EFF;"></i>  包下载中</span>
            <span v-else-if="scope.row.upgradeStatus===3"><i class="fa fa-circle" style="color: #E6A23C;"></i>  升级中</span>
            <span v-else-if="scope.row.upgradeStatus===4"><i class="fa fa-circle" style="color: #67C23A;"></i>  升级成功</span>
            <span v-else-if="scope.row.upgradeStatus===5"><i class="fa fa-circle" style="color: #F56C6C;"></i>  升级失败</span>
          </template>
        </el-table-column>
        <el-table-column align="center" show-overflow-tooltip prop="upgradeInfo" label="升级信息"/>
        <el-table-column align="center" show-overflow-tooltip prop="curver" label="当前版本"/>
        <el-table-column align="center" show-overflow-tooltip prop="reportTime" label="报告时间" />
      </el-table>
      <div align="right" style="margin-top: 15px">
        <el-pagination
                @size-change="sizeChange"
                @current-change="numChange"
                :current-page="pageNum"
                :page-size="pageSize"
                :page-sizes="[10, 20, 40, 100]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount">
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'taskDetails',
  data() {
    return {
      details: {},
      deviceList: [],
      listLoading: false,
      totalCount: 0,
      pageSize: 10,
      pageNum: 1,

    };
  },
  methods: {
    async loadDetails() {
      const params = { taskId: this.$route.query.taskId };
      const allRes = await Promise.all([this.$Fetch.taskDetailDevice(params), this.$Fetch.taskDetails(params)]);
      if (allRes[0]) {
        this.deviceList = allRes[0].result;
        this.totalCount = allRes[0].total;
        this.details = allRes[1] || {};
        this.getAllPros.forEach((item) => {
          if (item.id === this.details.productId) {
            this.details.productName = item.productName;
          }
        });
      }
    },
    async loadDevice() {
      this.listLoading = true;
      const params = { pageSize: this.pageSize, pageNum: this.pageNum, taskId: this.$route.query.taskId };
      const res = await this.$Fetch.taskDetailDevice(params);
      this.listLoading = false;
      if (res) {
        this.deviceList = res.result;
        this.totalCount = res.total;
      }
    },
    sizeChange(size) { this.pageSize = size; this.loadDevice(); },
    numChange(num) { this.pageNum = num; this.loadDevice(); },
  },
  created() {
    this.loadDetails();
  },
  mounted() {
  },
  computed: {
    ...mapGetters(['getAllPros']),
  },
  filters: {
    filToName(v) {
      if (v === 1) { return '整包'; }
      if (v === 2) { return '拆包'; }
      return '';
    },
  },
};
</script>
