<template>
  <div>
    <div class="proDetail">
      <div>
        <el-form :inline="true">
          <el-form-item label="设备名称：">
            <el-input v-model="deviceName" @keyup.enter.native="loadDeviceList" placeholder="请输入设备名称"/>
          </el-form-item>
          <el-form-item label="设备类别：">
            <el-input v-model="deviceType" @keyup.enter.native="loadDeviceList" placeholder="请输入设备类别"/>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="medium" @click="loadDeviceList">搜索</el-button>
          </el-form-item>
          <el-form-item>
            <el-button type="danger" size="medium" @click="doReset">重置</el-button>
          </el-form-item>
          <el-form-item>
            <el-button type="warning" size="medium" @click="oneDevice('oneRuleForm')">添加设备</el-button>
          </el-form-item>
          <el-form-item>
            <el-button type="success" size="medium" @click="batchDevice">批量添加</el-button>
          </el-form-item>
          <el-form-item>
            <!--<el-button plain size="medium">下载设备证书</el-button>-->
          </el-form-item>
        </el-form>
      </div>
      <el-table
              style="margin-top: 5px"
              :data="tableData"
              max-height="479"
              stripe
              highlight-current-row
              v-loading="deviceLoading"
              element-loading-text="数据加载中...">
        <el-table-column type="index" label="#" />
        <el-table-column align="center" show-overflow-tooltip label="设备名称">
          <template slot-scope="scope">
            <el-button @click="deviceClick(scope.row, 'detail')" type="text" size="small">{{scope.row.equipmentName}}</el-button>
          </template>
        </el-table-column>
        <el-table-column align="center" show-overflow-tooltip prop="equipmentType" label="设备类别" />
        <el-table-column align="center" show-overflow-tooltip prop="nodeType" label="节点类型">
          <template slot-scope="scope">
            <span v-if="scope.row.nodeType===1"><el-tag type="success">设备</el-tag></span>
            <span v-if="scope.row.nodeType===2"><el-tag type="warning">网关</el-tag></span>
          </template>
        </el-table-column>
        <el-table-column align="center" prop="runStatus" label="运行状态">
          <template slot-scope="scope">
            <span v-if="scope.row.runStatus===1">
              <span><i class="fa fa-circle" style="color: #67C23A;"></i>  在线</span>
            </span>
            <span v-if="scope.row.runStatus===2">
              <span><i class="fa fa-circle" style="color: #F56C6C;"></i>  离线</span>
            </span>
          </template>
        </el-table-column>
        <el-table-column align="center" show-overflow-tooltip prop="activateTime" label="激活时间">
          <template slot-scope="scope">
            <span v-if="scope.row.activateTime">{{scope.row.activateTime}}</span>
            <span v-if="!scope.row.activateTime">-</span>
          </template>
        </el-table-column>
        <el-table-column align="center" show-overflow-tooltip prop="addTime" label="添加时间" />
        <el-table-column align="center" label="操作" width="110">
          <template slot-scope="scope">
            <el-button @click="deviceClick(scope.row, 'detail')" type="text" size="small">详情</el-button>
            <el-button @click="deviceClick(scope.row, 'delete')" type="text" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div align="right" style="margin-top: 15px">
        <el-pagination
                @size-change="sizeChange"
                @current-change="pageChange"
                :current-page="pageNum"
                :page-size="pageSize"
                :page-sizes="[10, 20, 40, 100]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="新增设备" :visible.sync="oneDeviceVisible" width="40%">
      <el-form :model="form" :rules="oneRule" ref="oneRuleForm">
        <el-form-item label="设备名称：" :label-width="'120px'" prop="equipmentName">
          <el-input v-model="form.equipmentName" placeholder="请输入设备名称" />
        </el-form-item>
        <el-form-item label="设备类别：" :label-width="'120px'" prop="equipmentType">
          <el-input v-model="form.equipmentType" placeholder="请输入设备类别" />
        </el-form-item>
        <el-form-item label="设备备注：" :label-width="'120px'" prop="remark">
          <el-input v-model="form.remark" type="textarea" :rows="2" placeholder="请输入内容"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="oneDeviceVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOneDevice('oneRuleForm')">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog title="批量新增设备" :visible.sync="batchDeviceVisible" width="40%">
      <el-form :model="batchForm" :rules="batchRule" ref="batchInput">
        <el-form-item label="添加方式：" :label-width="'120px'" required>
          <el-radio-group v-model="batchForm.upType" size="medium">
            <el-radio-button label="自动生成"/><el-radio-button label="批量上传"/>
          </el-radio-group>
        </el-form-item>
        <el-form-item v-show="batchForm.upType==='自动生成'" label="设备数量：" :label-width="'120px'" required>
          <el-input-number size="medium" v-model="batchForm.count" controls-position="right" :min="0" :max="1000"/>
        </el-form-item>
        <el-form-item v-show="batchForm.upType==='批量上传'" label="上传附件：" :label-width="'120px'" required>
          <div>
            <el-upload
                    ref="uploadFile"
                    action=""
                    :http-request="myUpload"
                    :file-list="fileLists"
                    :auto-upload="false">
              <el-button slot="trigger" size="small" :type="hasFile?'':'danger'">
                <i class="el-icon-upload el-icon--right"></i>
                选取文件
              </el-button>
              <div slot="tip" class="el-upload__tip">
                单个文件不超过2M，一次最多包含1000条记录，<span style="color: #20a0ff;text-decoration: underline;cursor: pointer" @click="downFile">下载CSV模板</span>。
              </div>
            </el-upload>
          </div>
        </el-form-item>
        <el-form-item label="设备类别：" :label-width="'120px'" prop="equipmentType">
          <el-input v-model="batchForm.equipmentType" placeholder="请输入设备类别" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="batchDeviceVisible = false">取 消</el-button>
        <el-button :loading="batchUp" type="primary" @click="addBatchDevice('batchInput')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'deviceList',
  data() {
    const equipNameReg = (rule, value, callback) => {
      const isReg = /^([0-9a-zA-Z]){1,17}$/i.test(value);
      if (!isReg) { callback(new Error('支持1-17位的英文或数字')); }
      callback();
    };
    const equipTypeReg = (rule, value, callback) => {
      const isReg = /^([a-zA-Z0-9\u4e00-\u9fa5]){1,32}$/.test(value);
      const len = value.replace(/[\u4e00-\u9fa5]/g, 'aa').length;
      if (!isReg) { callback(new Error('支持1-32位的中英文或数字')); }
      if (len < 1 || len > 32) { callback(new Error('不能为空，长度1-32位.')); }
      callback();
    };
    const equipMarkReg = (rule, value, callback) => {
      const len = value.replace(/[\u4e00-\u9fa5]/g, 'aa').length;
      const spaceReg = /\s+/g.test(value);
      if (len < 1 || len > 255) { callback(new Error('不能为空，长度1-255位.')); }
      if (spaceReg) { callback(new Error('设备备注不能有空格！')); }
      callback();
    };
    return {
      deviceName: '',
      deviceType: '',
      tableData: [],
      deviceLoading: false,
      totalCount: 0,
      pageNum: 1,
      pageSize: 10,
      oneDeviceVisible: false,
      batchDeviceVisible: false,
      form: {
        equipmentName: '',
        equipmentType: '',
        remark: '',
      },
      fileLists: [],
      batchForm: {
        upType: '自动生成',
        count: 0,
        equipmentType: '',
      },
      oneRule: {
        equipmentName: [
          { required: true, validator: equipNameReg },
        ],
        equipmentType: [
          { required: true, validator: equipTypeReg },
        ],
        remark: [
          { required: true, validator: equipMarkReg },
        ],
      },
      batchRule: {
        equipmentType: [{ required: true, validator: equipTypeReg }],
      },
      hasFile: true,
      batchUp: false,
    };
  },
  methods: {
    doReset() {
      this.deviceName = '';
      this.deviceType = '';
      this.pageNum = 1;
      this.pageSize = 10;
      this.loadDeviceList();
    },
    oneDevice(formName) {
      this.oneDeviceVisible = true;
      this.$nextTick(() => { this.$refs[formName].resetFields(); });
    },
    addOneDevice(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          const res = await this.$Fetch.addDevice(Object.assign(this.form, { productId: this.$route.query.productId }));
          if (res) {
            this.oneDeviceVisible = false;
            this.$message.success(res);
            this.loadDeviceList();
          }
        }
      });
    },
    batchDevice() {
      this.batchDeviceVisible = true;
      this.batchUp = false;
      this.hasFile = true;
      this.$nextTick(() => { this.$refs.batchInput.resetFields(); });
      this.batchForm.count = 0;
      this.batchForm.upType = '自动生成';
    },
    downFile() {
      const form = document.createElement('form');
      form.id = 'form';
      form.name = 'form';
      form.style.display = 'none';
      document.body.appendChild(form);
      const input = document.createElement('input');
      input.type = 'text';
      form.appendChild(input);
      form.action = '/iot-ctrl/device/templateDowndload';
      form.method = 'get';
      form.submit();
      $('#form').remove();
    },
    beforeUp(params) {
      const fileSuffix = /(?:xls|xlsx|csv)$/.test(params.name);
      if (!fileSuffix) {
        this.$message.error('上传文件类型只支持xls、xlsx、csv；请重新选择！');
        this.$refs.uploadFile.uploadFiles.length = 0;
        this.batchUp = false;
        return false;
      }
      const fileSize = Math.round(params.size / 1024 / 1024);
      if (fileSize > 2) {
        this.$message.warning(`${params.name}文件大小超过2M！`);
        this.$refs.uploadFile.uploadFiles.length = 0;
        this.batchUp = false;
        return false;
      }
      return true;
    },
    async myUpload(param) {
      const size = await this.beforeUp(param.file);
      if (!size) return;
      const form = new FormData();
      form.append('file', param.file);
      form.append('equipmentType', this.batchForm.equipmentType);
      form.append('productId', this.$route.query.productId);
      const res = await this.$Fetch.upFiles(form);
      if (res) this.$message.success(res); this.loadDeviceList(); this.batchDeviceVisible = false; this.batchUp = false;
    },
    addBatchDevice(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          Object.assign(this.batchForm, { productId: this.$route.query.productId });
          if (this.batchForm.upType === '自动生成') {
            if (this.batchForm.count === 0) { this.$message.error('设备数量不能为0'); return; }
            this.batchUp = true;
            const res = await this.$Fetch.addBatchDevices(this.batchForm);
            if (res) { this.$message.success(res); this.loadDeviceList(); }
            this.batchDeviceVisible = false;
            this.batchUp = false;
          }
          if (this.batchForm.upType === '批量上传') {
            this.batchUp = true;
            if (!this.$refs.uploadFile.uploadFiles.length) {
              this.hasFile = false;
              this.batchUp = false;
              this.$message.error('附件不能为空，请先选取文件！');
              return;
            }
            this.$refs.uploadFile.submit();
          }
        }
      });
    },
    async loadDeviceList() {
      const params = {
        equipmentName: this.deviceName,
        equipmentType: this.deviceType,
        productId: this.$route.query.productId,
      };
      this.deviceLoading = true;
      const res = await this.$Fetch.devicesList(Object.assign(params, { pageNum: this.pageNum, pageSize: this.pageSize }));
      this.deviceLoading = false;
      if (res) {
        this.tableData = res.result;
        this.totalCount = res.total;
      }
    },
    sizeChange(size) { this.pageSize = size; this.loadDeviceList(); },
    pageChange(num) { this.pageNum = num; this.loadDeviceList(); },
    async deviceClick(row, str) {
      if (str === 'detail') {
        await this.$store.commit('setDevId', row.id);
        this.$router.push({
          path: '/DeviceDetail/DevInfo', query: { deviceId: row.id },
        });
      }
      if (str === 'delete') {
        this.$confirm('此操作将永久删除该设备, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(async () => {
          const res = await this.$Fetch.deleteDevice({ id: row.id });
          this.$message.success(res); this.loadDeviceList();
        }).catch(() => {});
      }
    },
  },
  created() {
    this.loadDeviceList();
  },
  mounted() {},
  computed: {
    ...mapGetters([]),
  },
  watch: {
    'batchForm.upType': {
      handler() {
        this.batchForm.count = 0;
        this.batchForm.equipmentType = '';
        this.$nextTick(() => { this.$refs.batchInput.resetFields(); this.fileLists = []; });
      },
    },
  },
};
</script>
