<template>
  <div class="proDetail animated fadeIn">
    <h3>
      服务器端订阅
    </h3>
    <div style="font-size: 14px">
      服务端可以直接订阅产品下配置的所有类型的消息。一旦配置，物联网平台内部会立即将消息通过HTTP/2通道推送，这一部分按照消息条数计费，请及时消费消息。
    </div>
    <div>
      <el-table :data="tableData" border style="width: 32%;margin-top: 15px">
        <el-table-column align="center" prop="infoType" label="订阅消息类型" />
        <el-table-column align="center" prop="isSub" label="是否订阅">
          <template slot-scope="scope">
            <el-radio v-model="scope.row.isSub" label="1">是</el-radio>
            <el-radio v-model="scope.row.isSub" label="0">否</el-radio>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
export default {
  name: 'serSub',
  data() {
    return {
      tableData: [
        { infoType: '设备上报消息', isSub: '1' },
        { infoType: '设备状态变化通知', isSub: '0' },
      ],
    };
  },
  methods: {},
  created() {
  },
  mounted() {},
  computed: {},
};
</script>
