<template>
  <div class="proDetail">
    <div>
      <el-button :disabled="getProDetails.transparent===1" type="primary" size="medium" @click="showTopicForm">定义Topic类</el-button>
    </div>
    <div style="margin-top: 15px" class="animated fadeIn">
      <el-table :data="topicLists" :max-height="520" stripe v-loading="topicLoading" element-loading-text="数据加载中...">
        <el-table-column type="index" label="#" />
        <el-table-column align="center" show-overflow-tooltip prop="topicName" label="TOPIC类" />
        <el-table-column align="center" show-overflow-tooltip label="设备操作权限">
          <template slot-scope="scope">
            <el-tag v-if="scope.row.rightValue===4" type="warning">
              {{scope.row.rightValue | rightFilter}}
            </el-tag>
            <el-tag v-else-if="scope.row.rightValue===2" type="success">
              {{scope.row.rightValue | rightFilter}}
            </el-tag>
            <el-tag v-else-if="scope.row.rightValue===6" type="plain">
              {{scope.row.rightValue | rightFilter}}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column align="center" show-overflow-tooltip prop="remark" label="备注" />
        <el-table-column align="center" label="操作" width="110">
          <template slot-scope="scope">
            <el-button @click="proTopicClick(scope.row, 'edit')" type="text" size="small">编辑</el-button>
            <el-button @click="proTopicClick(scope.row, 'delete')" type="text" size="small">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div align="right" style="margin-top: 10px">
        <el-pagination
                @size-change="sizeChange"
                @current-change="pageChange"
                :current-page="pageNum"
                :page-size="pageSize"
                :page-sizes="[10, 20, 40, 100]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="定义Topic类" :visible.sync="topicVisible" :width="dynamicWidth <= 1500 ? '50%' : '45%'" top="1%" :before-close="diaClose">
      <el-form :model="form" :rules="topicRules" ref="topicForm">
        <el-form-item label="Topic类：" :label-width="'130px'" prop="topicName">
          <div class="topicForm">
            <div class="preInput">
              <el-input v-model="form.topicName" placeholder="请输入Topic类">
                <template slot="prepend">/sf/iot/{{getProDetails.productKey}}/${deviceName}/</template>
              </el-input>
            </div>
          </div>
        </el-form-item>
        <el-form-item label="命令ID：" :label-width="'130px'" prop="protoDataId">
          <el-input v-model="form.protoDataId" placeholder="请输入数字ID" />
        </el-form-item>
        <el-form-item label="包体长度：" :label-width="'130px'" prop="length">
          <el-row>
            <el-col :span="22">
              <el-input v-model="form.length" placeholder="请输入数字包体长度(n、N代表不定长)" />
            </el-col>
            <el-col :span="2" style="padding-left: 15px;">
              <div>
                <el-tooltip class="item" effect="light" placement="top">
                  <div slot="content">
                    包体长度值为正整数时，则要与以下表格内的字段长度的和相等；n、N则不定长。
                  </div>
                  <i class="el-icon-info"></i>
                </el-tooltip>
              </div>
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item label="主题操作权限：" :label-width="'130px'" prop="rightValue">
          <el-select v-model="form.rightValue" placeholder="请选择">
            <el-option label="订阅" value="4"/>
            <el-option label="发布" value="2"/>
            <el-option label="订阅和发布" value="6"/>
          </el-select>
        </el-form-item>
        <el-form-item label="主题备注：" :label-width="'130px'" prop="remark">
          <el-input v-model="form.remark" type="textarea" :rows="2" placeholder="请输入内容" />
        </el-form-item>
        <el-form-item v-show="form.dataStructure.fields.length===0">
          <el-button type="success" size="medium" @click="addOne('init')">增加</el-button>
        </el-form-item>
        <el-table :data="form.dataStructure.fields" stripe max-height="200">
          <el-table-column type="index" label="#" />
          <el-table-column align="center" show-overflow-tooltip label="字段名称">
            <template slot-scope="scope">
              <span v-show="!scope.row.isEdit">{{scope.row.name}}</span>
              <el-input :maxlength="100" v-show="scope.row.isEdit" v-model.trim="scope.row.name" size="small" placeholder="请输入字段名" />
            </template>
          </el-table-column>
          <el-table-column align="center" label="字段长度（byte）">
            <template slot-scope="scope">
              <span v-show="!scope.row.isEdit">{{scope.row.length}}</span>
              <el-input :disabled="scope.row.disInput" v-show="scope.row.isEdit" v-model.number="scope.row.length" size="small" placeholder="请输入数值长度" />
            </template>
          </el-table-column>
          <el-table-column align="center" label="字段类型">
            <template slot-scope="scope">
              <span v-show="!scope.row.isEdit">{{scope.row.type}}</span>
              <el-select @change="typeSelect(scope.row)" clearable size="small" v-show="scope.row.isEdit" v-model="scope.row.type" placeholder="请选择">
                <el-option v-for="item in options" :key="item.label" :label="item.label" :value="item.value"/>
              </el-select>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="100">
            <template slot-scope="scope">
              <el-button type="text" size="mini" @click="addOne(scope.$index)">增加</el-button>
              <el-button type="text" size="mini" @click="deleteOne(scope.$index)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="topicVisible = false">取 消</el-button>
        <el-button type="primary" @click="addOneTopic('topicForm')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'infoTel',
  data() {
    const topicNameReg = (rule, value, callback) => {
      const isReg = /[\u4e00-\u9fa5]/g.test(value);
      const spaceReg = /\s+/g.test(value);
      if (isReg || spaceReg) { callback(new Error('topic类不能有中文、不能有空格！')); }
      callback();
    };
    const orderReg = (rule, value, callback) => {
      const isNum = /^[0-9]+$/.test(value);
      if (!isNum || value > 1023) { callback(new Error('请输入大于0且小于1023的正整数！')); }
      callback();
    };
    const numberReg = (rule, value, callback) => {
      const isNum = /^[0-9nN]+$/.test(value);
      if (!isNum) { callback(new Error('请输入大于0的正整数或者N、n！')); }
      callback();
    };
    return {
      topicLists: [],
      totalCount: 0,
      pageNum: 1,
      pageSize: 10,
      topicLoading: false,
      topicVisible: false,
      form: {
        topicName: '',
        rightValue: '',
        remark: '',
        protoDataId: '',
        length: '',
        dataStructure: {
          fields: [],
        },
      },
      options: [
        { label: 'BINARY', value: 'BINARY' },
        { label: 'BYTE', value: 'BYTE' },
        { label: 'UNBYTE', value: 'UNBYTE' },
        { label: 'WORD', value: 'WORD' },
        { label: 'UNWORD', value: 'UNWORD' },
        { label: 'DWORD', value: 'DWORD' },
        { label: 'UNDWORD', value: 'UNDWORD' },
        { label: 'BYTE[n]', value: 'BYTE[n]' },
        { label: 'BCD[n]', value: 'BCD[n]' },
        { label: 'ASCII', value: 'ASCII' },
        { label: 'plain', value: 'plain' },
      ],
      topicRules: {
        topicName: [{ required: true, validator: topicNameReg }],
        protoDataId: [{ required: true, validator: orderReg }],
        length: [{ required: true, validator: numberReg }],
        rightValue: [{ required: true, message: '请选择设备操作权限' }],
        remark: [{ required: true, message: '请输入设备备注' }],
      },
      dynamicWidth: '',
    };
  },
  methods: {
    typeSelect(row) {
      // eslint-disable-next-line
      row.disInput = false;
      if (row.type === 'BYTE' || row.type === 'UNBYTE') {
        // eslint-disable-next-line
        row.disInput = true;
        // eslint-disable-next-line
        row.length = 1;
      }
      if (row.type === 'WORD' || row.type === 'UNWORD') {
        // eslint-disable-next-line
        row.disInput = true;
        // eslint-disable-next-line
        row.length = 2;
      }
      if (row.type === 'DWORD' || row.type === 'UNDWORD') {
        // eslint-disable-next-line
        row.disInput = true;
        // eslint-disable-next-line
        row.length = 4;
      }
    },
    addOne(index) {
      const tempObj = {
        name: '',
        length: '',
        type: '',
        isEdit: true,
      };
      if (index === 'init') {
        this.form.dataStructure.fields.push(tempObj);
      }
      if (index !== 'init') {
        this.form.dataStructure.fields.splice(index + 1, 0, tempObj);
      }
    },
    deleteOne(index) {
      this.$confirm('确认删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(() => {
        this.form.dataStructure.fields.splice(index, 1);
        this.$message.success('删除成功!');
      }).catch(() => {});
    },
    diaClose(done) { this.$confirm('确认关闭？', { type: 'warning' }).then(() => { done(); }).catch(() => {}); },
    showTopicForm() {
      this.topicVisible = true;
      this.$nextTick(() => {
        this.form = {
          topicName: '',
          rightValue: '',
          remark: '',
          protoDataId: '',
          length: '',
          dataStructure: {
            fields: [],
          },
        };
        this.$refs.topicForm.resetFields();
      });
    },
    addOneTopic(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          // eslint-disable-next-line
          this.form.realTopicName = '/sf/iot/' + this.getProDetails.productKey + '/${deviceName}/' + this.form.topicName;
          this.form.productId = Number(this.$route.query.productId);
          let lengthList = 0;
          // eslint-disable-next-line
          for (let item of this.form.dataStructure.fields) {
            if (!item.name || !item.length || !item.type) {
              this.$message.warning('表格内有数据为空项且字段长度不能为0！');
              return;
            }
            lengthList += item.length;
          }
          if (this.form.length !== 'n' && this.form.length !== 'N') {
            if (lengthList !== Number(this.form.length)) {
              this.$message.warning('表格内的length长度之和要与包体长度相等！');
              return;
            }
          }
          await this.$Fetch.addMesInfo(this.form, this);
        }
      });
    },
    async proTopicClick(row, str) {
      if (str === 'edit') {
        const res = await this.$Fetch.getMegItem({ topicId: row.id });
        if (res) {
          this.form.topicName = res.topicName.split('/')[5];
          this.form.rightValue = String(res.rightValue);
          this.form.remark = res.remark;
          if (res.dataStructure) {
            this.form.dataStructure = JSON.parse(res.dataStructure);
            this.form.dataStructure.fields.forEach((item) => {
              // eslint-disable-next-line
              item.isEdit = true;
              this.typeSelect(item);
            });
            this.form.id = this.form.dataStructure.id;
            this.form.protoDataId = this.form.dataStructure.id;
            this.form.length = this.form.dataStructure.length;
          } else {
            this.form.dataStructure = {
              fields: [],
            };
          }
          this.form.editId = row.id;
          this.topicVisible = true;
        }
      }
      if (str === 'delete') {
        this.$confirm('此操作将永久删除该topic, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(async () => {
          const res = await this.$Fetch.deleteItem({ id: row.id });
          this.$message.success(res); this.loadProTopics();
        }).catch(() => {});
      }
    },
    async loadProTopics() {
      this.topicLoading = true;
      const params = { productId: this.$route.query.productId, pageSize: this.pageSize, pageNum: this.pageNum };
      const res = await this.$Fetch.proTopicList(params);
      this.topicLoading = false;
      this.topicLists = res.result;
      if (res) { this.totalCount = res.length; }
    },
    sizeChange(size) { this.pageSize = size; this.loadProTopics(); },
    pageChange(num) { this.pageNum = num; this.loadProTopics(); },
  },
  created() {
    this.loadProTopics();
  },
  filters: {
    rightFilter(v) {
      if (v === 4) {
        return '订阅';
      } else if (v === 2) {
        return '发布';
      }
      return '订阅和发布';
    },
  },
  mounted() {
    this.dynamicWidth = this.getDynamicWidth;
  },
  computed: {
    ...mapGetters([
      'getProDetails',
      'getDynamicWidth',
    ]),
  },
};
</script>
