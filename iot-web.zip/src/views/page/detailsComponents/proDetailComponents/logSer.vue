<template>
  <div class="proDetail">
    <div class="innerSame">
      <div>
        <el-form :inline="true">
          <el-form-item label="输入设备名称：">
            <el-input v-model="deviceName" @keyup.enter.native="onSearch" placeholder="请输入设备名称"/>
          </el-form-item>
          <el-form-item label="输入消息ID：">
            <el-input v-model="messageId" @keyup.enter.native="onSearch" placeholder="请输入消息ID"/>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="medium" @click="onSearch">搜索</el-button>
          </el-form-item>
        </el-form>
      </div>
      <div style="margin-top: 18px">
        <span style="padding-right: 15px">
          <el-button type="text">今日</el-button>
          <el-button type="text">本周</el-button>
        </span>
        <el-date-picker
                @change="logDateChange"
                v-model="selectDate"
                type="daterange"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期">
        </el-date-picker>
      </div>
    </div>
    <div style="margin-top: 18px">
      <el-radio-group v-model="kind" size="medium">
        <el-radio-button label="设备行为分析"/>
        <el-radio-button label="上行信息分析"/>
        <el-radio-button label="下行信息分析"/>
      </el-radio-group>
      <el-table
              style="margin-top: 5px"
              :data="tableData"
              max-height="424"
              stripe
              highlight-current-row
              v-loading="logLoading"
              element-loading-text="数据加载中...">
        <el-table-column type="index" label="#" />
        <el-table-column align="center" show-overflow-tooltip prop="productId" label="时间" />
        <el-table-column align="center" show-overflow-tooltip prop="productName" label="产品名称" />
        <el-table-column align="center" show-overflow-tooltip prop="ownApp" label="设备名称" />
        <el-table-column align="center" prop="onlineDevices" label="日志内容" />
        <el-table-column label="操作" width="65">
          <template slot-scope="scope">
            <el-button @click="rowClick(scope.row)" type="text" size="small">详情</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div align="right" style="margin-top: 15px">
        <el-pagination
                @size-change="sizeChange"
                @current-change="pageChange"
                :current-page="pageNum"
                :page-size="pageSize"
                :page-sizes="[10, 20, 40, 100]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount">
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'logSer',
  data() {
    return {
      deviceName: '',
      messageId: '',
      selectDate: [],
      kind: '上行信息分析',
      tableData: [],
      totalCount: 0,
      pageNum: 1,
      pageSize: 10,
      logLoading: false,
    };
  },
  methods: {
    onSearch() {
      // todo
    },
    logDateChange() {
      // todo
    },
    rowClick() {
      // todo
    },
    sizeChange(size) { console.info(size, this.pageSize); },
    pageChange(num) { console.info(num, this.pageNum); },
  },
  created() {
  },
  mounted() {},
  computed: {
    ...mapGetters([]),
  },
};
</script>
