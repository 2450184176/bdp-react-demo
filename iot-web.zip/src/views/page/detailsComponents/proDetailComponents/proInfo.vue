<template>
  <div>
    <div class="proDetail animated fadeIn">
      <div class="adjustCss">
        <div class="item_1">
          <div style="max-width: 250px;word-wrap: break-word">
            <p>产品名称</p>
            <p>{{getProDetails.productName}}</p>
          </div>
          <div>
            <p>所属部门</p>
            <p>{{getProDetails.productDept}}</p>
          </div>
        </div>
        <div class="item_2">
          <div>
            <p>创建时间</p>
            <p>{{getProDetails.creatTime}}</p>
          </div>
          <div>
            <p>产品类型</p>
            <p v-if="getProDetails.productType===1"><el-tag type="success">设备</el-tag></p>
            <p v-if="getProDetails.productType===2"><el-tag type="warning">网关</el-tag></p>
          </div>
        </div>
        <div class="item_3">
          <div>
            <p>最后修改时间</p>
            <p>{{getProDetails.lastModifyTime}}</p>
          </div>
          <div>
            <p>创建人</p>
            <p>{{getProDetails.creater}}</p>
          </div>
        </div>
        <div class="item_4">
          <div style="max-width: 250px;word-wrap: break-word">
            <p>描述</p>
            <p>{{getProDetails.remark}}</p>
          </div>
          <div>
            <p>最后修改人</p>
            <p>{{getProDetails.lastModifer}}</p>
          </div>
        </div>
        <div class="item_5">
          <div>
            <p>是否透传</p>
            <p>{{getProDetails.transparent | isTransfer}}</p>
          </div>
          <div style="max-width: 250px;word-wrap: break-word">
            <p>第二责任人</p>
            <p>{{String(getProDetails.userIds)}}</p>
          </div>
        </div>
      </div>
    </div>
    <div class="proDetail">
      <h3>
        标签信息
      </h3>
      <el-tag :key="tag.id" v-for="tag in getLabels" closable :disable-transitions="false" @close="doRemove(tag)">
        {{tag.labelValue}}
      </el-tag>
      <el-dialog title="新建标签" :visible.sync="popVisible" width="25%">
        <el-form :model="labelData" ref="labelForm" :rules="rules">
          <el-form-item label="标签KEY：" :label-width="'115px'" prop="labelKey">
            <el-input v-model="labelData.labelKey" placeholder="请输入标签KEY"/>
          </el-form-item>
          <el-form-item label="标签VALUE：" :label-width="'115px'" prop="labelValue">
            <el-input v-model="labelData.labelValue" placeholder="请输入标签VALUE"/>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button size="mini" @click="popVisible = false">取消</el-button>
          <el-button type="primary" size="mini" @click="doAddLabel('labelForm')">确定</el-button>
        </div>
      </el-dialog>
      <el-button slot="reference" @click="showPop('labelForm')">+ 标签</el-button>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
  name: 'proInfo',
  data() {
    return {
      popVisible: false,
      labelData: { labelKey: '', labelValue: '' },
      rules: {
        labelKey: [
          { required: true, message: '请输入标签KEY' },
        ],
        labelValue: [
          { required: true, message: '请输入标签VALUE' },
        ],
      },
    };
  },
  methods: {
    ...mapActions([
      'getProDetail',
    ]),
    showPop(formName) {
      this.popVisible = true;
      this.$nextTick(() => { this.$refs[formName].resetFields(); });
    },
    doAddLabel(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          const res = await this.$Fetch.addLabel({ labels: [this.labelData], productId: Number(this.$route.query.productId) });
          if (res) {
            await this.getProDetail(this.$route.query.productId);
            this.popVisible = false;
            this.$message.success(res);
          }
        }
      });
    },
    doRemove(item) {
      this.$confirm('此操作将永久删除该标签, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      }).then(async () => {
        const res = await this.$Fetch.deleteLabel({ id: item.id });
        if (res) {
          await this.getProDetail(this.$route.query.productId);
          this.$message.success('删除成功!');
        }
      }).catch(() => {});
    },
  },
  computed: {
    ...mapGetters([
      'userName',
      'getProDetails',
      'getLabels',
    ]),
  },
  filters: {
    isTransfer(v) {
      if (v === 1) { return '是'; }
      if (v === 2) { return '否'; }
      return 'null';
    },
  },
};
</script>
<style scoped>
  .el-tag + .el-tag {
    margin-left: 10px;
  }
</style>
