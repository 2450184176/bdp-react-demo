<template>
  <div>
    <div class="proDetail animated fadeIn">
      <h3>{{form.ruleName}}</h3>
      <div class="adjustCss">
        <div class="item_1">
          <div>
            <p>创建人：</p>
            <p>{{form.creater}}</p>
          </div>
          <div>
            <p>创建时间：</p>
            <p>{{form.createTime}}</p>
          </div>
        </div>
        <div class="item_2">
          <div>
            <p>最后修改人：</p>
            <p>{{form.lastModifer}}</p>
          </div>
          <div>
            <p>启动时间：</p><p>{{form.startDate}}</p>
          </div>
        </div>
        <div class="item_3">
          <div>
            <p>最后编辑时间：</p><p>{{form.lastModifyTime}}</p>
          </div>
          <div>
            <p>备注：</p><p>{{form.remark}}</p>
          </div>
        </div>
      </div>
    </div>
    <div class="proDetail">
      <div class="innerSame">
        <div>
          <h3>筛选数据</h3>
        </div>
        <div style="padding-top: 13px">
          <el-button size="small" type="primary" @click="editSql">编辑sql</el-button>
          <!--<el-button size="small">测试sql</el-button>-->
        </div>
      </div>
      <div class="sqlContent">
        <div>
          <span>当前sql语句时：</span>{{form.sqlStatement}}
        </div>
        <div>
          <span>字段：</span>{{form.fields}}
        </div>
        <div>
          <span>Topic：</span>{{form.mqttTopic}}
        </div>
      </div>
    </div>
    <div class="proDetail">
      <div class="innerSame">
        <div>
          <h3>操作行为</h3>
        </div>
        <div style="padding-top: 13px">
          <el-button size="small" type="primary" @click="showAddForm">添加行为</el-button>
        </div>
      </div>
      <div class="actType" v-for="item in acts" :key="item.id">
        <div class="leftTitle">
          <div class="lfTitle">{{item.forwardType | filterName}}</div>
          <div v-if="item.forwardType===1">
            <span>产品名称：{{item.productName}}</span>
            <span>MqttTopic：{{item.json.mqttTopic}}</span>
          </div>
          <div v-if="item.forwardType===2">
            <span>服务器IP：{{item.json.ip}}</span>
            <span>数据库用户名：{{item.json.username}}</span>
            <span>数据库密码：{{item.json.passWord}}</span>
            <span>数据库名称：{{item.json.dataBase}}</span>
            <span>数据库表名：{{item.json.dataTable}}</span>
          </div>
          <div v-if="item.forwardType===3">
            <span>Kafka集群：{{item.clusterName}}</span>
            <span>Kafka主题：{{item.json.kafkaTopic}}</span>
          </div>
        </div>
        <div>
          <el-button @click="forwardClick(item, 'edit')" type="text">修改</el-button>
          <el-button @click="forwardClick(item, 'delete')" type="text">删除</el-button>
        </div>
      </div>
    </div>
    <el-dialog title="编写SQL" :visible.sync="editSqlVisible" width="40%" top="5%">
      <el-form :model="sqlForm" :rules="sqlForms" ref="sqlForm">
        <el-form-item label="字段名：" :label-width="'120px'" prop="fields">
          <el-input type="textarea" v-model="sqlForm.fields" placeholder="请输入字段名" />
        </el-form-item>
        <el-form-item label="产品：" :label-width="'120px'" prop="productId">
          <el-select filterable clearable @change="getProIdTopic" v-model="sqlForm.productId" placeholder="请选择产品">
            <el-option v-for="item in getAllPros" :key="item.id" :label="item.productName" :value="item.id"/>
          </el-select>
        </el-form-item>
        <el-form-item label="Topic：" :label-width="'120px'" prop="mqttTopic">
          <el-select filterable clearable v-model="sqlForm.mqttTopic" placeholder="请选择Topic" :disabled="!sqlForm.productId">
            <el-option v-for="item in topics" :key="item.id" :label="item.topicName" :value="item.topicName+'+'+item.id"/>
          </el-select>
        </el-form-item>
        <el-form-item label="条件：" :label-width="'120px'" prop="whereStatement">
          <el-row>
            <el-col :span="22">
              <el-input v-model="sqlForm.whereStatement" placeholder="请输入条件" />
            </el-col>
            <el-col :span="2" style="padding-left: 30px;">
              <div>
                <el-tooltip class="item" effect="light" placement="top">
                  <div slot="content">
                    SQL支持AND & OR，WHERE支持=、<>、>、<、>=、<=
                    例：SELECT A,B,C FROM T WHERE A <> NULL AND (B > 0 OR C = "TEST")。
                  </div>
                  <i class="el-icon-info"></i>
                </el-tooltip>
              </div>
            </el-col>
          </el-row>
        </el-form-item>
        <div align="right" style="margin-bottom: 15px">
          <el-button type="primary" @click="generateSql">生 成</el-button>
        </div>
        <el-form-item label="SQL语句：" :label-width="'120px'">
          <el-input type="textarea" disabled v-model="txt" placeholder="请生成SQL语句" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="editSqlVisible = false">取 消</el-button>
        <el-button type="primary" @click="sureEditSql('sqlForm')">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog title="操作行为" :visible.sync="addVisible" width="40%">
      <el-form :model="addForm" :rules="addForms" ref="addForm">
        <el-form-item label="选择操作：" :label-width="'120px'" prop="type">
          <el-select v-model="addForm.type" placeholder="请选择" @change="changeType">
            <el-option label="发送到另外一个Topic" value="1"/>
            <el-option label="发送到mysql" value="2"/>
            <el-option label="发送到kafka" value="3"/>
          </el-select>
        </el-form-item>
        <div v-if="addForm.type==='1'">
          <el-form-item label="产品：" :label-width="'120px'" prop="productId">
            <el-select filterable clearable @change="getProIdTopic" v-model="addForm.productId" placeholder="请选择产品" clearable>
              <el-option v-for="item in getAllPros" :key="item.id" :label="item.productName" :value="item.id"/>
            </el-select>
          </el-form-item>
          <el-form-item label="Topic：" :label-width="'120px'" prop="mqttTopic">
            <el-select filterable clearable v-model="addForm.mqttTopic" placeholder="请选择Topic" clearable :disabled="!addForm.productId">
              <el-option v-for="item in topics" :key="item.id" :label="item.topicName" :value="item.topicName"/>
            </el-select>
          </el-form-item>
        </div>
        <div v-if="addForm.type==='2'">
          <el-form-item label="服务器IP和端口：" :label-width="'135px'" prop="ip">
            <el-input v-model="addForm.ip" clearable placeholder="请输入服务器IP和端口，例：127.0.0.1:3306" />
          </el-form-item>
          <el-form-item label="用户名：" :label-width="'135px'" prop="username">
            <el-input v-model="addForm.username" clearable placeholder="请输入用户名" />
          </el-form-item>
          <el-form-item label="密码：" :label-width="'135px'" prop="passWord">
            <el-input type="password" v-model="addForm.passWord" clearable placeholder="请输入用户名密码" />
          </el-form-item>
          <el-form-item label="数据库：" :label-width="'135px'" prop="dataBase">
            <el-input v-model="addForm.dataBase" clearable placeholder="请输入数据库" />
          </el-form-item>
          <el-form-item label="数据表：" :label-width="'135px'" prop="dataTable">
            <el-input v-model="addForm.dataTable" clearable placeholder="请输入数据表" />
          </el-form-item>
        </div>
        <div v-if="addForm.type==='3'">
          <el-form-item label="KAFKA集群：" :label-width="'120px'" prop="kafkaCluster">
            <el-select
                    @change="changeCluster"
                    v-model="addForm.kafkaCluster"
                    filterable
                    clearable
                    placeholder="请选择KAFKA集群">
              <el-option
                      v-for="cluster in getClusters.kafkaClusters"
                      :key="cluster.id"
                      :label="cluster.kafkaName"
                      :value="cluster.kafkaZk"/>
            </el-select>
          </el-form-item>
          <el-form-item label="TOPIC主题：" :label-width="'120px'" prop="kafkaTopic">
            <el-select
                    v-model="addForm.kafkaTopic"
                    filterable
                    remote
                    clearable
                    :remote-method="searchTo"
                    :loading="loading"
                    placeholder="请选择TOPIC主题">
              <el-option v-for="kafka in sliceKafkaTopics" :label="kafka" :value="kafka" :key="kafka"/>
            </el-select>
          </el-form-item>
        </div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button :loading="testCon" v-show="addForm.type==='2'" @click="testConnect('addForm')" type="success">测试连通性</el-button>
        <el-button @click="addVisible = false">取 消</el-button>
        <el-button type="primary" @click="sureAddAct('addForm')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'ruleDetail',
  data() {
    return {
      form: {},
      sqlForm: {
        fields: '',
        productId: '',
        mqttTopic: '',
        sqlStatement: '',
        whereStatement: '',
      },
      txt: '',
      topics: [],
      kafkaTopics: [],
      loading: false,
      sliceKafkaTopics: [],
      addForm: {
        type: '',
        productId: '',
        mqttTopic: '',
        ip: '',
        username: '',
        passWord: '',
        dataBase: '',
        dataTable: '',
        kafkaCluster: '',
        kafkaTopic: '',
      },
      acts: [],
      editSqlVisible: false,
      addVisible: false,
      sqlForms: {
        fields: [{ required: true, message: '请输入字段名称' }],
        productId: [{ required: true, message: '请选择产品' }],
        mqttTopic: [{ required: true, message: '请选择Topic' }],
      },
      addForms: {
        type: [{ required: true, message: '请选择操作' }],
        productId: [{ required: true, message: '请选择产品' }],
        mqttTopic: [{ required: true, message: '请选择topic' }],
        ip: [{ required: true, message: '请输入ip和端口' }],
        username: [{ required: true, message: '请输入用户名' }],
        passWord: [{ required: true, message: '请输入密码' }],
        dataBase: [{ required: true, message: '请输入数据库' }],
        dataTable: [{ required: true, message: '请输入数据表' }],
        kafkaCluster: [{ required: true, message: '请选择kafka集群' }],
        kafkaTopic: [{ required: true, message: '请选择kafka主题' }],
      },
      testCon: false,
    };
  },
  methods: {
    async editSql() {
      let tempMqttTopic = '';
      let to = '';
      if (this.form.sqlStatement) {
        const from = this.form.sqlStatement.indexOf('from');
        if (this.form.sqlStatement.includes('where')) {
          to = this.form.sqlStatement.indexOf('where');
        }
        tempMqttTopic = this.form.sqlStatement.substring(from + 4);
        if (to) { tempMqttTopic = this.form.sqlStatement.substring(from + 4, to); }
      }
      this.sqlForm.fields = this.form.fields;
      this.sqlForm.productId = this.form.productId;
      if (this.form.productId) {
        await this.getProIdTopic(this.form.productId);
      }
      this.sqlForm.mqttTopic = $.trim(tempMqttTopic);
      this.sqlForm.whereStatement = this.form.whereStatement;
      this.txt = '';
      this.editSqlVisible = true;
    },
    generateSql() {
      // eslint-disable-next-line
      this.sqlForm.whereStatement
        ? this.txt = `select ${this.sqlForm.fields} from ${this.sqlForm.mqttTopic} where ${this.sqlForm.whereStatement};`
        : this.txt = `select ${this.sqlForm.fields} from ${this.sqlForm.mqttTopic}`;
      if (this.sqlForm.mqttTopic.includes('+')) {
        // eslint-disable-next-line
        this.sqlForm.whereStatement
          ? this.txt = `select ${this.sqlForm.fields} from ${this.sqlForm.mqttTopic.split('+')[0]} where ${this.sqlForm.whereStatement};`
          : this.txt = `select ${this.sqlForm.fields} from ${this.sqlForm.mqttTopic.split('+')[0]}`;
      }
    },
    async getProIdTopic(v) {
      const params = { productId: v };
      const res = await this.$Fetch.getAllTopic(params);
      if (res) {
        this.topics = res;
        this.sqlForm.mqttTopic = '';
        this.addForm.mqttTopic = '';
      }
    },
    async changeCluster(v) {
      const params = { kafkaZk: v };
      this.kafkaTopics = await this.$Fetch.getKafkaTopic(params);
      this.sliceKafkaTopics = this.kafkaTopics.slice(0, 100);
    },
    searchTo(query) {
      if (query) {
        this.loading = true;
        // eslint-disable-next-line
        this.sliceKafkaTopics = this.kafkaTopics.filter((item) => { return item.toLowerCase().indexOf(query.toLowerCase()) > -1; });
      }
      this.sliceKafkaTopics = this.sliceKafkaTopics.slice(0, 100);
      setTimeout(() => { this.loading = false; }, 400);
    },
    changeType(v) {
      this.$refs.addForm.resetFields();
      this.addForm = {
        type: v,
        productId: '',
        mqttTopic: '',
        ip: '',
        passWord: '',
        dataBase: '',
        dataTable: '',
        kafkaCluster: '',
        kafkaTopic: '',
      };
    },
    sureEditSql(formName) {
      this.generateSql();
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          const params = {};
          params.id = this.$route.query.ruleId;
          params.productId = this.sqlForm.productId;
          params.fields = this.sqlForm.fields;
          params.mqttTopic = this.sqlForm.mqttTopic.includes('+') ? this.sqlForm.mqttTopic.split('+')[0] : this.sqlForm.mqttTopic;
          if (this.sqlForm.mqttTopic.includes('+')) {
            params.mqttTopicId = Number(this.sqlForm.mqttTopic.split('+')[1]);
          }
          params.whereStatement = this.sqlForm.whereStatement;
          params.sqlStatement = this.txt;
          const res = await this.$Fetch.add1Rule(params);
          if (res) {
            this.$message.success('保存成功！');
            this.loadRuleDetail();
            this.editSqlVisible = false;
          }
        }
      });
    },
    async loadListForward() {
      const params = { ruleId: this.$route.query.ruleId };
      const res = await this.$Fetch.forwardInfoList(params);
      const allPros = this.getAllPros;
      const clusters = this.getClusters;
      if (res) {
        res.forEach((item) => {
          // eslint-disable-next-line
          item.json = JSON.parse(item.json);
          if (item.forwardType === 1) {
            allPros.forEach((pro) => {
              // eslint-disable-next-line
              if (pro.id === item.json.productId) { item.productName = pro.productName; }
            });
          }
          if (item.forwardType === 3) {
            clusters.kafkaClusters.forEach((cluster) => {
              // eslint-disable-next-line
              if (cluster.kafkaZk === item.json.kafkaCluster) { item.clusterName = cluster.kafkaName; }
            });
          }
        });
        this.acts = res;
      }
    },
    showAddForm() { this.addVisible = true; this.addForm.type = ''; },
    async testConnect(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          this.testCon = true;
          const tempObj = {};
          tempObj.host = this.addForm.ip.split(':')[0];
          tempObj.port = this.addForm.ip.split(':')[1];
          tempObj.database = this.addForm.dataBase;
          tempObj.username = this.addForm.username;
          tempObj.password = this.addForm.passWord;
          const isConnect = await this.$Fetch.testConnection(tempObj);
          this.testCon = false;
          if (isConnect.includes('失败')) { this.$message.error(isConnect); return; }
          if (isConnect) this.$message.success(isConnect);
        }
      });
    },
    sureAddAct(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          const params = { ruleId: this.$route.query.ruleId, json: {}, id: this.addForm.id };
          if (this.addForm.type === '1') {
            params.forwardType = 1;
            params.json.typeName = '发送到另外一个Topic';
            params.json.productId = this.addForm.productId;
            params.json.mqttTopic = this.addForm.mqttTopic;
          }
          if (this.addForm.type === '2') {
            params.forwardType = 2;
            params.json.typeName = '发送到mysql';
            params.json.ip = this.addForm.ip;
            params.json.username = this.addForm.username;
            params.json.passWord = this.addForm.passWord;
            params.json.dataBase = this.addForm.dataBase;
            params.json.dataTable = this.addForm.dataTable;
          }
          if (this.addForm.type === '3') {
            params.forwardType = 3;
            params.json.typeName = '发送到kafka';
            params.json.kafkaCluster = this.addForm.kafkaCluster;
            params.json.kafkaTopic = this.addForm.kafkaTopic;
          }
          params.json = JSON.stringify(params.json);
          const res = await this.$Fetch.addForwardInfo(params);
          if (res) {
            this.$message.success(res);
            this.loadListForward();
            this.addVisible = false;
          }
        }
      });
    },
    async forwardClick(data, str) {
      if (str === 'delete') {
        const params = { forwardId: data.id };
        this.$confirm('此操作将永久删除该topic, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        }).then(async () => {
          const res = await this.$Fetch.delete1Forward(params);
          this.$message.success(res); this.loadListForward();
        }).catch(() => {});
      }
      if (str === 'edit') {
        this.addForm.type = String(data.forwardType);
        this.addForm.id = data.id;
        this.addVisible = true;
        if (data.forwardType === 1) {
          this.addForm.productId = data.json.productId;
          await this.getProIdTopic(this.addForm.productId);
          this.addForm.mqttTopic = data.json.mqttTopic;
        }
        if (data.forwardType === 2) {
          this.addForm.ip = data.json.ip;
          this.addForm.username = data.json.username;
          this.addForm.passWord = data.json.passWord;
          this.addForm.dataBase = data.json.dataBase;
          this.addForm.dataTable = data.json.dataTable;
        }
        if (data.forwardType === 3) {
          this.addForm.kafkaCluster = data.json.kafkaCluster;
          await this.changeCluster(data.json.kafkaCluster);
          this.addForm.kafkaTopic = data.json.kafkaTopic;
        }
      }
    },
    async loadRuleDetail() {
      const params = { id: this.$route.query.ruleId };
      const res = await this.$Fetch.ruleDetails(params);
      if (res) { this.form = res; }
    },
  },
  created() {
    this.loadRuleDetail();
    this.loadListForward();
  },
  mounted() {
  },
  computed: {
    ...mapGetters([
      'getAllPros',
      'getClusters',
    ]),
  },
  filters: {
    filterName(v) {
      if (v === 1) { return '发送到另外一个Topic'; }
      if (v === 2) { return '发送到mysql'; }
      if (v === 3) { return '发送到kafka'; }
      return '';
    },
  },
};
</script>
