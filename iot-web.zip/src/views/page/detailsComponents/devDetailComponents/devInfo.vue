<template>
  <div class="animated fadeIn">
    <div class="proDetail">
      <div class="adjustCss">
        <div class="item_1">
          <div style="max-width: 250px;word-wrap: break-word">
            <p>设备名称</p>
            <p>{{getDeviceDetails.equipmentName}}</p>
          </div>
          <div>
            <p>所属部门</p>
            <p>{{getDeviceDetails.productDept}}</p>
          </div>
        </div>
        <div class="item_2">
          <div>
            <p>节点类型</p>
            <p v-if="getDeviceDetails.nodeType===1"><el-tag type="success">设备</el-tag></p>
            <p v-if="getDeviceDetails.nodeType===2"><el-tag type="warning">网关</el-tag></p>
          </div>
          <div>
            <p>创建时间</p>
            <p>{{getDeviceDetails.addTime}}</p>
          </div>
        </div>
        <div class="item_3">
          <div>
            <p>创建人</p>
            <p>{{getDeviceDetails.creater}}</p>
          </div>
          <div>
            <p>最后修改时间</p>
            <p>{{getDeviceDetails.lastModifyTime}}</p>
          </div>
        </div>
        <div class="item_4">
          <div>
            <p>最后修改人</p>
            <p>{{getDeviceDetails.lastModifer}}</p>
          </div>
          <div style="max-width: 250px;word-wrap: break-word">
            <p>描述</p>
            <p>{{getDeviceDetails.remark}}</p>
          </div>
        </div>
      </div>
    </div>
    <div class="proDetail">
      <h3>
        设备秘钥
      </h3>
      <span class="productSecret">
          <span v-show="isShow" id="content">{{getDeviceDetails.equipmentSecret}}</span> <span v-show="!isShow">******</span>
          <span v-show="getDeviceDetails.equipmentSecret">
            <el-button
                    v-clipboard:copy="getDeviceDetails.equipmentSecret"
                    v-clipboard:success="onCopy"
                    v-clipboard:error="onError"
                    size="mini"
                    type="text">
              复制</el-button>
            <el-button size="mini" type="text" @click="isShow = !isShow">{{isShow ? '隐藏' : '显示'}}</el-button>
          </span>
        </span>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'devInfo',
  data() {
    return {
      isShow: false,
    };
  },
  methods: {
    onCopy() {
      const h = this.$createElement;
      this.$message({
        type: 'success',
        message: h('p', null, [
          h('span', null, '复制设备秘钥成功！'),
          h('i', { style: 'color: teal' }, `${this.getDeviceDetails.equipmentSecret}`),
        ]),
      });
    },
    onError() { this.$message.error('复制设备秘钥失败！'); },
  },
  async created() {
    await this.$store.commit('setDevId', this.$route.query.deviceId);
  },
  mounted() {},
  computed: {
    ...mapGetters([
      'getDeviceDetails',
    ]),
  },
};
</script>
