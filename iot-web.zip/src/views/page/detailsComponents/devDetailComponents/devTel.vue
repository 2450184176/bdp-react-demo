<template>
  <div class="proDetail animated fadeIn">
    <el-table
            style="margin-top: 5px"
            :data="tableData"
            stripe
            highlight-current-row
            v-loading="topicLoading"
            element-loading-text="数据加载中...">
      <el-table-column type="index" label="#" />
      <el-table-column align="center" show-overflow-tooltip prop="topicName" label="TOPIC类" />
      <el-table-column align="center" show-overflow-tooltip label="设备操作权限">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.rightValue===2" type="warning">
            {{scope.row.rightValue | rightFilter}}
          </el-tag>
          <el-tag v-else-if="scope.row.rightValue===4" type="success">
            {{scope.row.rightValue | rightFilter}}
          </el-tag>
          <el-tag v-else-if="scope.row.rightValue===6" type="plain">
            {{scope.row.rightValue | rightFilter}}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column align="center" show-overflow-tooltip prop="remark" label="备注" />
    </el-table>
    <div align="right" style="margin-top: 15px">
      <el-pagination
              @size-change="sizeChange"
              @current-change="pageChange"
              :current-page="pageNum"
              :page-size="pageSize"
              :page-sizes="[10, 20, 40, 100]"
              layout="total, sizes, prev, pager, next, jumper"
              :total="totalCount">
      </el-pagination>
    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'devTel',
  data() {
    return {
      tableData: [],
      totalCount: 0,
      pageNum: 1,
      pageSize: 10,
      topicLoading: false,
    };
  },
  methods: {
    async loadTopicData() {
      this.topicLoading = true;
      const params = { equipId: this.$route.query.deviceId, pageSize: this.pageSize, pageNum: this.pageNum };
      const res = await this.$Fetch.devTopicList(params);
      this.topicLoading = false;
      if (res) {
        this.tableData = res.result;
        this.totalCount = res.length;
      }
    },
    sizeChange(size) { this.pageSize = size; this.loadTopicData(); },
    pageChange(num) { this.pageNum = num; this.loadTopicData(); },
  },
  async created() {
    this.loadTopicData();
    await this.$store.commit('setDevId', this.$route.query.deviceId);
  },
  mounted() {},
  filters: {
    rightFilter(v) {
      if (v === 4) {
        return '订阅';
      } else if (v === 2) {
        return '发布';
      }
      return '发布和订阅';
    },
  },
  computed: {
    ...mapGetters([
      'getDeviceDetails',
    ]),
  },
};
</script>
