<template>
  <div class="proDetail animated fadeIn">
    <div style="display: flex;align-items: center;justify-content: space-between">
      <div style="font-size: 14px">
        <h3>设备影子</h3>
        <p>最后一次修改时间：{{getDeviceDetails.lastModifyTime}}</p>
      </div>
      <div>
        <el-button size="small" type="primary" @click="updateCode">刷新</el-button>
        <el-button size="small" @click="isClicked=!isClicked">{{!isClicked ? '修改' : '取消'}}</el-button>
      </div>
    </div>
    <div>
      <!--<el-input type="textarea" :rows="10" placeholder="请输入内容" :disabled="!isClicked" v-model="pyCode"/>-->
    </div>
    <div>
      <codemirror ref="myCm" :value="pyCode" :options="cmOptions" @ready="onCmReady" @input="onCmCodeChange"/>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';
import { codemirror } from 'vue-codemirror';
import 'codemirror/mode/python/python';
import 'codemirror/theme/base16-light.css';
import 'codemirror/lib/codemirror.css';
import 'codemirror/addon/hint/show-hint.css';
import 'codemirror/lib/codemirror';
import 'codemirror/addon/hint/show-hint';
import 'codemirror/addon/hint/anyword-hint';

export default {
  name: 'devSha',
  data() {
    return {
      isClicked: false,
      pyCode: '',
      cmOptions: {
        tabSize: 2,
        mode: 'text/x-python',
        theme: 'base16-light',
        lineNumbers: true,
        line: true,
        indentUnit: 4,
        lineWrapping: true,
        readOnly: true,
        cursorBlinkRate: -1,
      },
    };
  },
  methods: {
    ...mapActions([
      'getDeviceDetail',
    ]),
    assignPyCode() { this.pyCode = this.getDeviceDetails.shadow || localStorage.getItem('shadow'); },
    async updateCode() {
      const params = { productId: Number(localStorage.getItem('proId')), shadow: this.pyCode, id: this.$route.query.deviceId };
      const res = await this.$Fetch.addDevice(params);
      if (res) {
        this.getDeviceDetail(this.getDeviceId);
        this.$message.success(res);
      }
    },
    onCmReady(cm) {
      cm.on('keypress', () => {
        cm.showHint({ completeSingle: false });
      });
    },
    onCmCodeChange(newCode) { this.pyCode = newCode; },
  },
  async created() {
    await this.$store.commit('setDevId', this.$route.query.deviceId);
    this.assignPyCode();
  },
  components: {
    codemirror,
  },
  computed: {
    ...mapGetters([
      'getDeviceDetails',
      'getDeviceId',
    ]),
    codemirror() {
      return this.$refs.myCm.codemirror;
    },
  },
  watch: {
    isClicked(o, n) {
      if (n) { this.cmOptions.readOnly = true; this.cmOptions.theme = 'base16-light'; this.cmOptions.cursorBlinkRate = -1; this.assignPyCode(); }
      if (o) { this.cmOptions.readOnly = false; this.cmOptions.theme = 'default'; this.cmOptions.cursorBlinkRate = 500; this.codemirror.focus(); }
    },
  },
};
</script>
