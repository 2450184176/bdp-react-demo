<template>
  <div class="homePage">
    <div class="info">
      <div class="sameCss animated fadeIn">
        <div class="img"><img :src="devKind" alt=""></div>
        <div class="word">
          <p class="animated bounceIn">{{equipSituation.productCount}}</p>
          <p>产品种类</p>
        </div>
      </div>
      <div class="sameCss animated fadeIn">
        <div class="img"><img :src="devSum" alt=""></div>
        <div class="word">
          <p class="animated bounceIn">{{equipSituation.equipmentCount}}</p>
          <p>设备总数</p>
        </div>
      </div>
      <div class="sameCss animated fadeIn">
        <div class="img"><img :src="devOnline" alt=""></div>
        <div class="word">
          <p class="animated bounceIn">{{equipSituation.equipmentOnline}}/{{equipSituation.equipmentCount}}</p>
          <p>设备在线情况</p>
        </div>
      </div>
    </div>
    <div class="sameCss animated fadeIn">
      <bdp-table/>
    </div>
    <div class="sameCss appChart animated fadeIn">
      <app-chart/>
    </div>
    <div class="sameCss gatherChart animated fadeIn">
      <gather-chart/>
    </div>
    <div class="sameCss relayChart animated fadeIn">
      <relay-chart/>
    </div>
  </div>
</template>

<script>
import { mapActions } from 'vuex';
import bdpTable from '../commonComponents/homeComponents/bdpTable';
import appChart from '../commonComponents/homeComponents/appChart';
import gatherChart from '../commonComponents/homeComponents/gatherChart';
import relayChart from '../commonComponents/homeComponents/relayChart';

export default {
  name: 'pageHome',
  data() {
    return {
      equipSituation: {
        productCount: 0,
        equipmentCount: 0,
        equipmentOnline: 0,
      },
      devKind: 'static/img/devKind.png',
      devOnline: 'static/img/devOnline.png',
      devSum: 'static/img/devSum.png',
    };
  },
  components: {
    bdpTable,
    appChart,
    gatherChart,
    relayChart,
  },
  methods: {
    ...mapActions([]),
    async getEquipsSituation() {
      const res = await this.$Fetch.getEquipSituation();
      if (res) this.equipSituation = res;
    },
  },
  async created() {
    this.getEquipsSituation();
  },
};
</script>
