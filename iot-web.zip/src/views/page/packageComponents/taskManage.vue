<template>
  <div>
    <el-button size="mini" type="primary" @click="newUpTask">新建升级任务</el-button>
    <div class="upPackage animated fadeIn">
      <el-table :data="taskLists" stripe v-loading="taskLoading" element-loading-text="数据加载中...">
        <el-table-column align="center" type="index" label="#" />
        <el-table-column align="center" show-overflow-tooltip prop="taskName" label="任务名称">
          <template slot-scope="scope">
            <el-button @click="handleClick('detail', scope.row)" type="text" size="small">{{scope.row.taskName}}</el-button>
          </template>
        </el-table-column>
        <el-table-column align="center" show-overflow-tooltip prop="upgradeWay" label="升级方式">
          <template slot-scope="scope">
            <span v-if="scope.row.upgradeWay===1">整包</span>
            <span v-else-if="scope.row.upgradeWay===2">拆包</span>
          </template>
        </el-table-column>
        <el-table-column align="center" show-overflow-tooltip prop="createTime" label="上传时间" />
        <el-table-column align="center" label="操作" width="50">
          <template slot-scope="scope">
            <el-button size="mini" type="text" @click="handleClick('detail', scope.row)">详情</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div align="right" style="margin-top: 15px">
        <el-pagination
                @size-change="sizeChange"
                @current-change="numChange"
                :current-page="pageNum"
                :page-size="pageSize"
                :page-sizes="[10, 20, 40, 100]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCounts">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="创建升级任务" :visible.sync="addTaskVisible" :width="dynamicWidth <= 1500 ? '75%' : '45%'" top="5%">
      <el-form :model="taskForm" :rules="addTaskRule" ref="addTaskForm">
        <el-form-item label="选择包版本：" :label-width="'120px'" prop="packageId">
          <el-select filterable v-model="taskForm.packageId" placeholder="请选择包版本" clearable>
            <el-option v-for="item in packages" :key="item.id" :label="item.packageName +'_'+item.packageVer" :value="item.id"/>
          </el-select>
        </el-form-item>
        <el-form-item label="任务名称：" :label-width="'120px'" prop="taskName">
          <el-input v-model="taskForm.taskName" placeholder="请输入任务名称"/>
        </el-form-item>
        <el-form-item label="升级方式：" :label-width="'120px'" prop="upgradeWay">
          <el-radio v-model="taskForm.upgradeWay" label="1">整包</el-radio>
          <el-radio v-model="taskForm.upgradeWay" label="2">拆包</el-radio>
        </el-form-item>
        <el-form-item label="任务备注：" :label-width="'120px'" prop="taskRemark">
          <el-input v-model="taskForm.taskRemark" type="textarea" :rows="2" placeholder="请输入内容"/>
        </el-form-item>
        <el-form-item label="选择产品：" :label-width="'120px'" prop="productId">
          <el-select filterable @change="chooseDevice" v-model="taskForm.productId" placeholder="请选择产品" clearable>
            <el-option v-for="item in getAllPros" :key="item.id" :label="item.productName" :value="item.id"/>
          </el-select>
        </el-form-item>
        <el-form-item label="选择设备：" :label-width="'120px'" prop="deviceList">
          <el-table
                  style="margin-top: 5px;width: 100%;"
                  :data="tableData"
                  max-height="250"
                  stripe
                  @selection-change="mulSelect"
                  v-loading="deviceLoading">
            <el-table-column type="selection" label="#" />
            <el-table-column align="center" show-overflow-tooltip prop="equipmentName" label="设备名称"/>
            <el-table-column align="center" show-overflow-tooltip prop="nodeType" label="节点类型">
              <template slot-scope="scope">
                <p v-if="scope.row.nodeType===1"><el-tag type="success">设备</el-tag></p>
                <p v-if="scope.row.nodeType===2"><el-tag type="warning">网关</el-tag></p>
              </template>
            </el-table-column>
            <el-table-column align="center" prop="runStatus" label="运行状态">
              <template slot-scope="scope">
                <span v-if="scope.row.runStatus">
                  <span><i class="fa fa-circle" style="color: #67C23A;"></i>  在线</span>
                </span>
                <span v-if="!scope.row.runStatus">
                  <span><i class="fa fa-circle" style="color: #F56C6C;"></i>  离线</span>
                </span>
              </template>
            </el-table-column>
            <el-table-column align="center" show-overflow-tooltip prop="addTime" label="添加时间"/>
          </el-table>
          <div align="right" style="margin-top: 15px">
            <el-pagination
                    @size-change="dSChange"
                    @current-change="dNChange"
                    :current-page="dNum"
                    :page-size="dSize"
                    :page-sizes="upArr"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="tCounts">
            </el-pagination>
          </div>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addTaskVisible = false">取 消</el-button>
        <el-button type="primary" :loading="btnLoad" @click="sureSubTask('addTaskForm')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'taskManage',
  data() {
    const customValidate = (rule, value, callback) => {
      if (this.mulSelection.length > 0 && !this.mulSelection.length) {
        callback(new Error('请选择设备'));
      } callback();
    };
    return {
      taskLists: [],
      taskLoading: false,
      totalCounts: 0,
      pageSize: 10,
      pageNum: 1,
      addTaskVisible: false,
      dynamicWidth: '',
      btnLoad: false,
      deviceLoading: false,
      productId: '',
      taskForm: {
        packageId: '',
        taskName: '',
        upgradeWay: '',
        taskRemark: '',
        productId: '',
      },
      packages: [],
      tableData: [],
      tCounts: 0,
      dNum: 1,
      dSize: 10,
      mulSelection: [],
      addTaskRule: {
        packageId: { required: true, message: '请选择包版本' },
        taskName: { required: true, message: '请输入任务名称' },
        upgradeWay: { required: true, message: '请选择升级方式' },
        taskRemark: { required: true, message: '请输入任务备注' },
        productId: { required: true, message: '请选择产品' },
        deviceList: { required: true, validator: customValidate },
      },
      upArr: [10, 20, 40, 100],
    };
  },
  methods: {
    newUpTask() {
      this.tableData = [];
      this.tCounts = 0;
      this.btnLoad = false;
      this.addTaskVisible = true;
      this.loadAllPackages();
      this.$nextTick(() => {
        this.$refs.addTaskForm.resetFields();
      });
    },
    mulSelect(val) { this.mulSelection = val; },
    async chooseDevice(v) {
      this.productId = v;
      this.deviceLoading = true;
      const res = await this.$Fetch.devicesList(Object.assign({ productId: Number(v) }, { pageNum: this.dNum, pageSize: this.dSize }));
      this.deviceLoading = false;
      this.upArr = [10, 20, 40, 100];
      if (res) {
        this.tableData = res.result;
        this.tCounts = res.total;
        if (this.tCounts > 100) {
          this.upArr = this.upArr.concat(this.tCounts);
        }
      }
    },
    async sureSubTask(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          this.btnLoad = true;
          const params = {
            packageId: this.taskForm.packageId,
            taskName: this.taskForm.taskName,
            upgradeWay: Number(this.taskForm.upgradeWay),
            productId: this.taskForm.productId,
            taskRemark: this.taskForm.taskRemark,
          };
          const tempIds = [];
          this.mulSelection.forEach((item) => {
            tempIds.push(item.id);
          });
          params.equipIds = tempIds.join(',');
          const res = await this.$Fetch.upGradeTasks(params);
          this.btnLoad = false;
          if (res) { this.$message.success(res); this.addTaskVisible = false; this.loadTaskList(); }
        }
      });
    },
    async loadTaskList() {
      const params = {
        pageSize: this.pageSize,
        pageNum: this.pageNum,
      };
      const res = await this.$Fetch.tasksLists(params);
      if (res) {
        this.taskLists = res.result;
        this.totalCounts = res.total;
      }
    },
    sizeChange(size) { this.pageSize = size; this.loadTaskList(); },
    numChange(num) { this.pageNum = num; this.loadTaskList(); },
    dSChange(size) { this.dSize = size; this.chooseDevice(this.productId); },
    dNChange(num) { this.dNum = num; this.chooseDevice(this.productId); },
    async handleClick(str, row) {
      if (str === 'detail') {
        this.$router.push({ path: '/EdgeManage/taskDetails', query: { taskId: row.id } });
      }
    },
    async loadAllPackages() {
      const params = { pageSize: 10000, pageNum: 1 };
      const res = await this.$Fetch.allPackages(params);
      if (res) {
        this.packages = res.result;
      }
    },
  },
  created() {
    this.loadTaskList();
  },
  computed: {
    ...mapGetters([
      'getAllPros',
      'getDynamicWidth',
    ]),
  },
  mounted() {
    this.dynamicWidth = this.getDynamicWidth;
  },
};
</script>
