<template>
  <div>
    <el-button size="mini" type="primary" @click="newFirmware">新增升级包</el-button>
    <div class="upPackage animated fadeIn">
      <el-table :data="packages" stripe v-loading="firmwareLoading" element-loading-text="数据加载中...">
        <el-table-column align="center" type="index" label="#" />
        <el-table-column align="center" show-overflow-tooltip prop="packageName" label="包名称"/>
        <el-table-column align="center" show-overflow-tooltip prop="packageVer" label="包版本号" />
        <el-table-column align="center" show-overflow-tooltip prop="signAlgorithm" label="签名算法">
          <template slot-scope="scope">
            <span v-if="scope.row.signAlgorithm===1">MD5</span>
            <span v-else-if="scope.row.signAlgorithm===2">SHA256</span>
          </template>
        </el-table-column>
        <el-table-column align="center" show-overflow-tooltip prop="signValue" label="签名值" />
        <el-table-column align="center" show-overflow-tooltip prop="uploadTime" label="上传时间" />
        <el-table-column align="center" label="操作" width="125">
          <template slot-scope="scope">
            <el-button size="mini" type="text" @click="handleClick('check', scope.row)">验证签名</el-button>
            <el-button size="mini" type="text" @click="handleClick('upgrade', scope.row)">升级</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div align="right" style="margin-top: 15px">
        <el-pagination
                @size-change="sizeChange"
                @current-change="pageChange"
                :current-page="pageNum"
                :page-size="pageSize"
                :page-sizes="[10, 20, 40, 100]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount">
        </el-pagination>
      </div>
    </div>
    <el-dialog title="添加包" :visible.sync="addPackVisible" width="40%">
      <el-form :model="form" :rules="addPackRule" ref="addPackForm">
        <el-form-item label="包名称：" :label-width="'120px'" prop="packageName">
          <el-input v-model.trim="form.packageName" placeholder="请输入包名称"/>
        </el-form-item>
        <el-form-item label="包版本号：" :label-width="'120px'" prop="packageVer">
          <el-input v-model.trim="form.packageVer" placeholder="请输入包版本号"/>
        </el-form-item>
        <el-form-item label="签名算法：" :label-width="'120px'" prop="signAlgorithm">
          <el-radio v-model="form.signAlgorithm" label="1">MD5</el-radio>
          <el-radio v-model="form.signAlgorithm" label="2">SHA256</el-radio>
        </el-form-item>
        <el-form-item label="选择包：" :label-width="'120px'" required>
          <div>
            <el-upload
                    ref="uploadFile"
                    action=""
                    :http-request="myUpload"
                    :file-list="fileLists"
                    :auto-upload="false">
              <el-button slot="trigger" size="small" :type="hasFile?'':'danger'">
                <i class="el-icon-upload el-icon--right"></i>
                选取文件
              </el-button>
              <div slot="tip" class="el-upload__tip">
                仅支持bin,tar,gz,zip类型的文件
              </div>
            </el-upload>
          </div>
        </el-form-item>
        <el-form-item label="包备注：" :label-width="'120px'" prop="packageRemark">
          <el-input v-model.trim="form.packageRemark" type="textarea" :rows="2" placeholder="请输入内容"/>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addPackVisible = false">取 消</el-button>
        <el-button type="primary" :loading="btnLoad" @click="sureSub('addPackForm')">确 定</el-button>
      </div>
    </el-dialog>
    <el-dialog title="创建升级任务" :visible.sync="addTaskVisible" :width="dynamicWidth <= 1500 ? '75%' : '45%'" top="5%">
      <el-form :model="taskForm" :rules="addTaskRule" ref="addTaskForm">
        <el-form-item label="任务名称：" :label-width="'120px'" prop="taskName">
          <el-input v-model.trim="taskForm.taskName" placeholder="请输入任务名称"/>
        </el-form-item>
        <el-form-item label="升级方式：" :label-width="'120px'" prop="upgradeWay">
          <el-radio v-model="taskForm.upgradeWay" label="1">整包</el-radio>
          <el-radio v-model="taskForm.upgradeWay" label="2">拆包</el-radio>
        </el-form-item>
        <el-form-item label="任务备注：" :label-width="'120px'" prop="taskRemark">
          <el-input v-model.trim="taskForm.taskRemark" type="textarea" :rows="2" placeholder="请输入内容"/>
        </el-form-item>
        <el-form-item label="选择产品：" :label-width="'120px'" prop="productId">
          <el-select filterable @change="chooseDevice" v-model="taskForm.productId" placeholder="请选择产品" clearable>
            <el-option v-for="item in getAllPros" :key="item.id" :label="item.productName" :value="item.id"/>
          </el-select>
        </el-form-item>
        <el-form-item label="选择设备：" :label-width="'120px'" prop="deviceList">
          <el-table
                  style="margin-top: 5px;width: 100%;"
                  :data="tableData"
                  max-height="250"
                  stripe
                  @selection-change="mulSelect"
                  v-loading="deviceLoading">
            <el-table-column type="selection" label="#" />
            <el-table-column align="center" show-overflow-tooltip prop="equipmentName" label="设备名称"/>
            <el-table-column align="center" show-overflow-tooltip label="节点类型">
              <template slot-scope="scope">
                <p v-if="scope.row.nodeType===1"><el-tag type="success">设备</el-tag></p>
                <p v-if="scope.row.nodeType===2"><el-tag type="warning">网关</el-tag></p>
              </template>
            </el-table-column>
            <el-table-column align="center" prop="runStatus" label="运行状态">
              <template slot-scope="scope">
                <span v-if="scope.row.runStatus">
                  <span><i class="fa fa-circle" style="color: #67C23A;"></i>  在线</span>
                </span>
                    <span v-if="!scope.row.runStatus">
                  <span><i class="fa fa-circle" style="color: #F56C6C;"></i>  离线</span>
                </span>
              </template>
            </el-table-column>
            <el-table-column align="center" show-overflow-tooltip prop="addTime" label="添加时间"/>
          </el-table>
          <div align="right" style="margin-top: 15px">
            <el-pagination
                    @size-change="dSChange"
                    @current-change="dNChange"
                    :current-page="dNum"
                    :page-size="dSize"
                    :page-sizes="upArr"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="tCounts">
            </el-pagination>
          </div>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addTaskVisible = false">取 消</el-button>
        <el-button type="primary" :loading="btnLoad" @click="sureSubTask('addTaskForm')">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'upPackage',
  data() {
    const customValidate = (rule, value, callback) => {
      if (this.mulSelection.length > 0 && !this.mulSelection.length) {
        callback(new Error('请选择设备'));
      }
      callback();
    };
    const packNameReg = (rule, value, callback) => {
      const len = value.replace(/[\u4e00-\u9fa5]/g, 'aa').length;
      if (len < 1 || len > 32) { callback(new Error('不能为空，长度为1-32位.')); }
      callback();
    };
    const packVerReg = (rule, value, callback) => {
      const len = value.replace(/[\u4e00-\u9fa5]/g, 'aa').length;
      if (len < 1 || len > 4) { callback(new Error('不能为空，长度为1-4位.')); }
      callback();
    };
    return {
      packages: [],
      firmwareLoading: false,
      totalCount: 0,
      pageNum: 1,
      pageSize: 10,
      addPackVisible: false,
      addTaskVisible: false,
      dynamicWidth: '',
      btnLoad: false,
      hasFile: true,
      deviceLoading: false,
      productId: '',
      tableData: [],
      tCounts: 0,
      dNum: 1,
      dSize: 10,
      mulSelection: [],
      fileLists: [],
      taskForm: {
        taskName: '',
        upgradeWay: '',
        taskRemark: '',
        productId: '',
      },
      form: {
        packageName: '',
        packageVer: '',
        signAlgorithm: '',
        packageRemark: '',
      },
      addPackRule: {
        packageName: { required: true, validator: packNameReg },
        packageVer: { required: true, validator: packVerReg },
        signAlgorithm: { required: true, message: '请选择签名算法' },
        packageRemark: { required: true, message: '请输入包备注' },
      },
      addTaskRule: {
        taskName: { required: true, message: '请输入任务名称' },
        upgradeWay: { required: true, message: '请选择升级方式' },
        taskRemark: { required: true, message: '请输入任务备注' },
        productId: { required: true, message: '请选择产品' },
        deviceList: { required: true, validator: customValidate },
      },
      upArr: [10, 20, 40, 100],
    };
  },
  methods: {
    sizeChange(size) { this.pageSize = size; this.loadPackages(); },
    pageChange(num) { this.pageNum = num; this.loadPackages(); },
    dSChange(size) { this.dSize = size; this.chooseDevice(this.productId); },
    dNChange(num) { this.dNum = num; this.chooseDevice(this.productId); },
    newFirmware() {
      this.addPackVisible = true;
      this.fileLists = [];
      this.btnLoad = false;
      this.hasFile = true;
      this.$nextTick(() => { this.$refs.addPackForm.resetFields(); });
    },
    sureSub(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          this.btnLoad = true;
          if (!this.$refs.uploadFile.uploadFiles.length) {
            this.hasFile = false;
            this.btnLoad = false;
            this.$message.error('附件不能为空，请先选取文件！');
            return;
          }
          this.$refs.uploadFile.submit();
        }
      });
    },
    async chooseDevice(v) {
      this.productId = v;
      this.deviceLoading = true;
      const res = await this.$Fetch.devicesList(Object.assign({ productId: Number(v) }, { pageNum: this.dNum, pageSize: this.dSize }));
      this.deviceLoading = false;
      this.upArr = [10, 20, 40, 100];
      if (res) {
        this.tableData = res.result;
        this.tCounts = res.total;
        if (this.tCounts > 100) {
          this.upArr = this.upArr.concat(this.tCounts);
        }
      }
    },
    async sureSubTask(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          this.btnLoad = true;
          const params = {
            taskName: this.taskForm.taskName,
            upgradeWay: Number(this.taskForm.upgradeWay),
            productId: this.taskForm.productId,
            taskRemark: this.taskForm.taskRemark,
            packageId: this.taskForm.packageId,
          };
          const tempIds = [];
          this.mulSelection.forEach((item) => {
            tempIds.push(item.id);
          });
          params.equipIds = tempIds.join(',');
          const res = await this.$Fetch.upGradeTasks(params);
          this.btnLoad = false;
          if (res) { this.$message.success(res); this.addTaskVisible = false; }
        }
      });
    },
    async loadPackages() {
      const params = { pageSize: this.pageSize, pageNum: this.pageNum };
      this.firmwareLoading = true;
      const res = await this.$Fetch.allPackages(params);
      this.firmwareLoading = false;
      if (res) {
        this.packages = res.result;
        this.totalCount = res.total;
      }
    },
    beforeUp(params) {
      const fileSuffix = /(?:bin|tar|gz|zip)$/.test(params.name);
      if (!fileSuffix) {
        this.$message.error('上传文件类型只支持bin、tar、gz、zip；请重新选择！');
        this.$refs.uploadFile.uploadFiles.length = 0;
        this.btnLoad = false;
        return false;
      }
      const fileSize = Math.round(params.size / 1024 / 1024);
      if (fileSize > 100) {
        this.$message.warning(`${params.name}文件大小超过100M！`);
        this.$refs.uploadFile.uploadFiles.length = 0;
        return false;
      }
      return true;
    },
    async myUpload(param) {
      const size = await this.beforeUp(param.file);
      if (!size) return;
      const formData = new FormData();
      formData.append('file', param.file);
      formData.append('packageName', this.form.packageName);
      formData.append('packageVer', this.form.packageVer);
      formData.append('signAlgorithm', Number(this.form.signAlgorithm));
      formData.append('packageRemark', this.form.packageRemark);
      const res = await this.$Fetch.upPackageAjax(formData);
      this.addPackVisible = false;
      this.btnLoad = false;
      if (res) {
        this.$message.success(res);
        this.loadPackages();
      }
    },
    mulSelect(val) { this.mulSelection = val; },
    async handleClick(str, row) {
      if (str === 'check') {
        const params = {
          packagePath: row.packagePath,
          signValue: row.signValue,
          signAlgorithm: row.signAlgorithm,
        };
        const res = await this.$Fetch.checkPackage(params);
        if (res.includes('不')) { this.$message.error(res); return; }
        if (res) this.$message.success(res);
      }
      if (str === 'upgrade') {
        this.tableData = [];
        this.tCounts = 0;
        this.btnLoad = false;
        this.addTaskVisible = true;
        this.taskForm.packageId = row.id;
        this.$nextTick(() => {
          this.$refs.addTaskForm.resetFields();
        });
      }
    },
  },
  created() {
    this.loadPackages();
  },
  computed: {
    ...mapGetters([
      'getAllPros',
      'getDynamicWidth',
    ]),
  },
  mounted() {
    this.dynamicWidth = this.getDynamicWidth;
  },
};
</script>
