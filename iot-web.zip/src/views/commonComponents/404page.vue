<template lang="pug">
  .pageError
    | 您访问的页面不存在！！
</template>

<script>
export default {
  name: 'page404',
  data() {
    return {};
  },
  methods: {
    tick404() {
      this.$alert('<strong>您访问的页面不存在</strong>', '提示', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        callback: () => { window.location.href = '/'; },
      });
    },
  },
  created() {
    this.tick404();
  },
};
</script>
