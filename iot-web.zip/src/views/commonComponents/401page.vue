<template lang="pug">
  .pageError
    | 您没有权限查看！！
</template>

<script>
export default {
  name: 'page401',
  data() {
    return {};
  },
  methods: {
    tick401(str) {
      this.$alert(`<strong>${str}</strong>`, '提示', {
        dangerouslyUseHTMLString: true,
        type: 'warning',
        callback: () => { window.location.href = '/'; },
      });
    },
  },
  created() {
    this.tick401(this.$route.query.check);
  },
};
</script>
