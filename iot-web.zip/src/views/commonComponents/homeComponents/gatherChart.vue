<template>
  <div class="animated fadeIn">
    <div class="infoTitle">收集情况</div>
    <div class="innerSame chooseOpe">
      <div>
        <el-form :inline="true">
          <el-form-item label="选择产品：">
            <el-select filterable @change="gatherChange('', 'pro')" v-model="productId" placeholder="请选择产品" clearable>
              <el-option v-for="item in getAllPros" :key="item.id" :label="item.productName" :value="item.id"/>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <div>
        <span style="padding-right: 15px">
          <el-button plain @click="gatherChange(1, 'btn')">小时</el-button>
          <el-button plain @click="gatherChange(2, 'btn')">天</el-button>
          <el-button plain @click="gatherChange(3, 'btn')">月</el-button>
        </span>
        <el-date-picker
                @change="gatherChange('', 'date')"
                value-format="yyyy-MM-dd"
                v-model="selectDate"
                type="daterange"
                :picker-options="pickerOptions"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期">
        </el-date-picker>
      </div>
    </div>
    <div id="gatherChart" style="width: 100%;height:400px;"></div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'gatherChart',
  data() {
    return {
      productId: '',
      selectDate: [],
      pickerOptions: {
        disabledDate(time) {
          const curDate = (new Date()).getTime();
          const oneMonth = 30 * 24 * 3600 * 1000;
          const monthOne = curDate - oneMonth;
          return time.getTime() > Date.now() || time.getTime() < monthOne;
        },
      },
      xyData: {},
      xData: [],
      yData: [],
    };
  },
  methods: {
    async gatherChange(kind, x) {
      this.xyData = {};
      this.xData = [];
      this.yData = [];
      const params = { productId: this.productId };
      if (x === 'btn' || x === 'pro') {
        this.xyData = await this.$Fetch.getUpMessage(Object.assign(params, { type: kind }));
      }
      if (x === 'date') {
        if (this.selectDate) {
          Object.assign(params, { startDate: this.selectDate[0], endDate: this.selectDate[1] });
        } else {
          Object.assign(params, { startDate: '', endDate: '' });
        }
        this.xyData = await this.$Fetch.getUpMessage(params);
      }
      if (this.xyData) {
        this.xData = this.xyData.keys;
        this.yData = this.xyData.values;
      }
      this.$nextTick(() => {
        this.drawPicture('gatherChart');
      });
    },
    // 画图
    drawPicture(id) {
      const myChart = this.$eCharts.init(document.getElementById(id));// 获取容器元素
      const option = {
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          data: ['消息上行数', '消息下行数'],
        },
        calculable: true,
        dataZoom: [{
          show: true,
          realtime: true,
          start: 40,
          end: 80,
        }],
        xAxis: [
          {
            type: 'category',
            data: this.xData,
          },
        ],
        yAxis: [
          { type: 'value' },
        ],
        series: [
          {
            name: '消息上行数',
            type: 'line',
            data: this.yData,
            smooth: 0.5,
            itemStyle: {
              normal: {
                color: '#3782FF',
              },
            },
          },
          {
            name: '消息下行数',
            type: 'line',
            data: [],
            smooth: 0.5,
            itemStyle: {
              normal: {
                color: '#2BE2F3',
              },
            },
          },
        ],
      };
      myChart.setOption(option);
    },
  },
  computed: {
    ...mapGetters([
      'getAllPros',
    ]),
  },
  created() {
    this.gatherChange('', 'btn');
  },
  mounted() {
    this.$nextTick(() => {
      this.drawPicture('gatherChart');
    });
  },
};
</script>
