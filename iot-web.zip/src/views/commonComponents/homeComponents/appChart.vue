<template>
  <div class="animated fadeIn">
    <div class="infoTitle">设备情况</div>
    <div class="innerSame chooseOpe">
      <div>
        <el-form :inline="true">
          <el-form-item label="选择产品：">
            <el-select filterable @change="appCharts('', 'pro')" v-model="productId" placeholder="请选择产品" clearable>
              <el-option v-for="item in getAllPros" :key="item.id" :label="item.productName" :value="item.id"/>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <div>
        <span style="padding-right: 15px">
          <el-button plain @click="appCharts(1, 'btn')">小时</el-button>
          <el-button plain @click="appCharts(2, 'btn')">天</el-button>
          <el-button plain @click="appCharts(3, 'btn')">月</el-button>
        </span>
        <el-date-picker
                @change="appCharts('', 'date')"
                value-format="yyyy-MM-dd"
                v-model="selectDate"
                type="daterange"
                :picker-options="pickerOptions"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期">
        </el-date-picker>
      </div>
    </div>
    <div id="appChart" style="width: 100%;height:400px;"></div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'appChart',
  data() {
    return {
      productId: '',
      selectDate: '',
      xyData: {},
      xData: [],
      yData: [],
      pickerOptions: {
        disabledDate(time) {
          const curDate = (new Date()).getTime();
          const oneMonth = 30 * 24 * 3600 * 1000;
          const monthOne = curDate - oneMonth;
          return time.getTime() > Date.now() || time.getTime() < monthOne;
        },
      },
    };
  },
  methods: {
    async appCharts(kind, x) {
      this.xyData = {};
      this.xData = [];
      this.yOnData = [];
      this.yAllData = [];
      const params = { productId: this.productId };
      if (x === 'btn' || x === 'pro') {
        this.xyData = await this.$Fetch.getOnOffEquips(Object.assign(params, { type: kind }));
      }
      if (x === 'date') {
        if (this.selectDate) {
          Object.assign(params, { startDate: this.selectDate[0], endDate: this.selectDate[1] });
        } else {
          Object.assign(params, { startDate: '', endDate: '' });
        }
        this.xyData = await this.$Fetch.getOnOffEquips(params);
      }
      if (this.xyData) {
        this.xData = this.xyData.keys;
        this.yOnData = this.xyData.values;
        this.yAllData = this.xyData.totals;
      }
      this.$nextTick(() => {
        this.drawPicture('appChart');
      });
    },
    // 画图
    drawPicture(id) {
      const myChart = this.$eCharts.init(document.getElementById(id));
      const options = {
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          data: ['设备总数', '设备在线情况'],
        },
        calculable: true,
        xAxis: [
          {
            type: 'category',
            data: this.xData,
            axisLabel: {
              interval: 0,
              rotate: 20,
            },
          },
        ],
        yAxis: [
          { type: 'value' },
        ],
        series: [
          {
            name: '设备总数',
            type: 'bar',
            data: this.yAllData,
            barWidth: this.getDynamicWidth < 1450 ? 15 : 20,
            itemStyle: {
              normal: {
                color: '#3782FF',
              },
            },
          },
          {
            name: '设备在线情况',
            type: 'bar',
            data: this.yOnData,
            barWidth: this.getDynamicWidth < 1450 ? 15 : 20,
            itemStyle: {
              normal: {
                color: '#2BE2F3',
              },
            },
          },
        ],
      };
      myChart.setOption(options); // 设置option
    },
  },
  async created() {
    await this.appCharts('', 'btn');
  },
  computed: {
    ...mapGetters([
      'getAllPros',
      'getDynamicWidth',
    ]),
  },
  mounted() {
    this.$nextTick(() => {
      this.drawPicture('appChart');
    });
  },
};
</script>
