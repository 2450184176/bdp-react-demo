<template>
  <div class="animated fadeIn">
    <div class="infoTitle">转发情况</div>
    <div class="innerSame chooseOpe">
      <div>
        <el-form :inline="true">
          <el-form-item label="选择产品：">
            <el-select filterable @change="relayChange('', 'pro')" v-model="productId" placeholder="请选择产品" clearable>
              <el-option v-for="item in getAllPros" :key="item.id" :label="item.productName" :value="item.id"/>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <div>
        <span style="padding-right: 15px">
          <el-button plain @click="relayChange(1, 'btn')">小时</el-button>
          <el-button plain @click="relayChange(2, 'btn')">天</el-button>
          <el-button plain @click="relayChange(3, 'btn')">月</el-button>
        </span>
        <el-date-picker
                @change="relayChange('', 'date')"
                value-format="yyyy-MM-dd"
                v-model="selectDate"
                type="daterange"
                :picker-options="pickerOptions"
                range-separator="至"
                start-placeholder="开始日期"
                end-placeholder="结束日期">
        </el-date-picker>
      </div>
    </div>
    <div id="relayChart" style="width: 100%;height:400px;"></div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';

export default {
  name: 'relayChart',
  data() {
    return {
      productId: '',
      selectDate: [],
      pickerOptions: {
        disabledDate(time) {
          const curDate = (new Date()).getTime();
          const oneMonth = 30 * 24 * 3600 * 1000;
          const monthOne = curDate - oneMonth;
          return time.getTime() > Date.now() || time.getTime() < monthOne;
        },
      },
      xData: [],
      ruleGotData: [],
      ruleShareData: [],
    };
  },
  methods: {
    async relayChange(kind, x) {
      this.xyData = {};
      this.xData = [];
      this.ruleGotData = [];
      this.ruleShareData = [];
      const params = { productId: this.productId };
      if (x === 'btn' || x === 'pro') {
        this.xyData = await this.$Fetch.getRules(Object.assign(params, { type: kind }));
      }
      if (x === 'date') {
        if (this.selectDate) {
          Object.assign(params, { startDate: this.selectDate[0], endDate: this.selectDate[1] });
        } else {
          Object.assign(params, { startDate: '', endDate: '' });
        }
        this.xyData = await this.$Fetch.getRules(params);
      }
      if (this.xyData) {
        this.xData = this.xyData.keys;
        this.ruleGotData = this.xyData.values;
        this.ruleShareData = this.xyData.totals; // 后面再加
      }
      this.$nextTick(() => {
        this.drawPicture('relayChart');
      });
    },
    // 画图
    drawPicture(id) {
      const myChart = this.$eCharts.init(document.getElementById(id));// 获取容器元素
      const option = {
        tooltip: {
          trigger: 'axis',
        },
        legend: {
          data: ['规则转发数', '规则命中数'],
        },
        toolbox: {
          show: false,
          feature: {
            mark: { show: true },
            dataView: { show: true, readOnly: false },
            magicType: { show: true, type: ['line', 'bar'] },
            restore: { show: true },
            saveAsImage: { show: true },
          },
        },
        calculable: true,
        dataZoom: {
          show: true,
          realtime: true,
          start: 30,
          end: 70,
        },
        xAxis: [
          {
            type: 'category',
            data: this.xData,
          },
        ],
        yAxis: [
          { type: 'value' },
        ],
        series: [
          {
            name: '规则转发数',
            type: 'line',
            data: this.ruleGotData,
            smooth: 0.5,
            itemStyle: {
              normal: {
                color: '#3782FF',
              },
            },
          },
          {
            name: '规则命中数',
            type: 'line',
            data: [],
            smooth: 0.5,
            itemStyle: {
              normal: {
                color: '#2BE2F3',
              },
            },
          },
        ],
      };
      myChart.setOption(option); // 设置option
    },
  },
  computed: {
    ...mapGetters([
      'getAllPros',
    ]),
  },
  async created() {
    await this.relayChange('', 'btn');
  },
  mounted() {
    this.$nextTick(() => {
      this.drawPicture('relayChart');
    });
  },
};
</script>
