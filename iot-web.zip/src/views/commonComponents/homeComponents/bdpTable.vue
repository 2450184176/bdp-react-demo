<template>
  <div class="animated fadeIn">
    <div>
      <el-table
              :data="tableData"
              max-height="520"
              stripe
              highlight-current-row
              v-loading="productLoading"
              element-loading-text="数据加载中...">
        <el-table-column align="center" type="index" label="#" width="50" />
        <el-table-column align="center" show-overflow-tooltip prop="productName" label="产品名称">
          <template slot-scope="scope">
            <el-button @click="handleClick(scope.row)" type="text" size="small">{{scope.row.productName}}</el-button>
          </template>
        </el-table-column>
        <el-table-column align="center" show-overflow-tooltip prop="productKey" label="产品Key" />
        <el-table-column align="center" show-overflow-tooltip prop="protocolType" label="产品协议" />
        <el-table-column align="center" prop="online" label="设备在线数" />
        <el-table-column align="center" prop="offline" label="设备离线数" />
        <el-table-column align="center" label="操作" width="65">
          <template slot-scope="scope">
            <el-button @click="handleClick(scope.row)" type="text" size="small">详情</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div align="right" style="margin-top: 15px">
        <el-pagination
                @size-change="sizeChange"
                @current-change="pageChange"
                :current-page="pageNum"
                :page-size="pageSize"
                :page-sizes="[10, 20, 40, 100]"
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalCount">
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'bdpTable',
  data() {
    return {
      productLoading: false,
      tableData: [],
      totalCount: 0,
      pageNum: 1,
      pageSize: 10,
    };
  },
  methods: {
    async getProList(page, size) {
      this.productLoading = true;
      const res = await this.$Fetch.productList({ pageNum: page, pageSize: size });
      this.productLoading = false;
      if (res) {
        this.tableData = res.result;
        this.totalCount = res.total;
      }
    },
    async handleClick(row) {
      await this.$store.commit('setProId', row.id);
      this.$router.push({
        path: '/ProductDetail/ProInfo', query: { productId: row.id },
      });
    },
    sizeChange(xSize) { this.getProList(this.pageNum, xSize); },
    pageChange(yNum) { this.getProList(yNum, this.pageSize); },
  },
  async created() {
    this.getProList(this.pageNum, this.pageSize);
  },
};
</script>
