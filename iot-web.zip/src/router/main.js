const Home = () => import('@/views/page/pageHome');
const ProductsList = () => import('@/views/page/childComponents/productsList');
const ProductDetail = () => import('@/views/page/detailsComponents/productsDetail');
const DeviceDetail = () => import('@/views/page/detailsComponents/deviceDetail');
const DevInfo = () => import('@/views/page/detailsComponents/devDetailComponents/devInfo');
const DevTel = () => import('@/views/page/detailsComponents/devDetailComponents/devTel');
const DevSha = () => import('@/views/page/detailsComponents/devDetailComponents/devSha');
const ProInfo = () => import('@/views/page/detailsComponents/proDetailComponents/proInfo');
const DeviceList = () => import('@/views/page/detailsComponents/proDetailComponents/deviceList');
const InfoTel = () => import('@/views/page/detailsComponents/proDetailComponents/infoTel');
const SerSub = () => import('@/views/page/detailsComponents/proDetailComponents/serSub');
const LogSer = () => import('@/views/page/detailsComponents/proDetailComponents/logSer');
const RulesEngine = () => import('@/views/page/childComponents/rulesEngine');
const RuleDetail = () => import('@/views/page/detailsComponents/rulesDetail');
const EdgeManage = () => import('@/views/page/childComponents/edgeManage');
const upPackage = () => import('@/views/page/packageComponents/upPackage');
const taskManage = () => import('@/views/page/packageComponents/taskManage');
const taskDetails = () => import('@/views/page/detailsComponents/taskDetails');
const DataAnalysis = () => import('@/views/page/childComponents/dataAnalysis');
const StatusMon = () => import('@/views/page/childComponents/statusMon');


const Page401 = () => import('@/views/commonComponents/401page');
const Page404 = () => import('@/views/commonComponents/404page');


export default [
  { path: '/', component: Home, meta: { title: '主页' } },
  {
    path: '/ProductsList',
    name: 'productsList',
    meta: { title: '产品列表' },
    component: ProductsList,
  },
  {
    path: '/ProductDetail',
    name: 'productsDetail',
    meta: { title: '产品详情' },
    component: ProductDetail,
    children: [
      {
        path: 'ProInfo',
        name: 'proInfo',
        meta: { title: '产品信息' },
        component: ProInfo,
      },
      {
        path: 'DeviceList',
        name: 'deviceList',
        meta: { title: '设备列表' },
        component: DeviceList,
      },
      {
        path: 'InfoTel',
        name: 'infoTel',
        meta: { title: '消息通信' },
        component: InfoTel,
      },
      {
        path: 'SerSub',
        name: 'serSub',
        meta: { title: '服务端订阅' },
        component: SerSub,
      },
      {
        path: 'LogSer',
        name: 'logSer',
        meta: { title: '日志服务' },
        component: LogSer,
      },
    ],
  },
  {
    path: '/DeviceDetail',
    name: 'deviceDetail',
    meta: { title: '设备详情' },
    component: DeviceDetail,
    children: [
      {
        path: 'DevInfo',
        name: 'devInfo',
        meta: { title: '设备信息' },
        component: DevInfo,
      },
      {
        path: 'DevTel',
        name: 'devTel',
        meta: { title: '设备通信' },
        component: DevTel,
      },
      {
        path: 'DevSha',
        name: 'devSha',
        meta: { title: '设备影子' },
        component: DevSha,
      },
    ],
  },
  {
    path: '/RulesEngine',
    name: 'rulesEngine',
    meta: { title: '规则引擎' },
    component: RulesEngine,
  },
  {
    path: '/StatusMon',
    name: 'statusMon',
    meta: { title: '状态监控' },
    component: StatusMon,
  },
  {
    path: '/RuleDetail',
    name: 'ruleDetail',
    meta: { title: '规则详情' },
    component: RuleDetail,
  },
  {
    path: '/EdgeManage/taskDetails',
    name: 'taskDetails',
    meta: { title: '升级任务详情' },
    component: taskDetails,
  },
  {
    path: '/EdgeManage',
    name: 'edgeManage',
    meta: { title: '边缘计算' },
    component: EdgeManage,
    children: [
      {
        path: 'upPackage',
        name: 'upPackage',
        meta: { title: '升级包列表' },
        component: upPackage,
      },
      {
        path: 'taskManage',
        name: 'taskManage',
        meta: { title: '升级任务列表' },
        component: taskManage,
      },
    ],
  },
  {
    path: '/DataAnalysis',
    name: 'dataAnalysis',
    meta: { title: '数据分析' },
    component: DataAnalysis,
  },
  { path: '/Page401', component: Page401, meta: { title: '您没有权限查看此页面！' } },
  { path: '*', component: Page404 },
];
