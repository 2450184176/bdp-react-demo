<template lang="pug">
  el-container#app
    el-header(height='65px')
      head-nav(:menus='navItems', :nav-info='headInfo', @logout="$store.dispatch('userLogOut')")
        .log(slot='logo')
          a(@click="toPortal" title='顺丰大数据平台')
            img(src='static/img/iotLogo.png')
          a.log-text(href='#/', title='万物互联') 万物互联
          div(style="height: 50px;width:3px;background-color: black;margin-left:42px")
    el-main
      breadCrumb
      router-view
      footerCopyright
</template>

<script>
import { mapActions, mapGetters } from 'vuex';
import breadCrumb from '@/components/breadCrumb';
import footerCopyright from '@/components/footer-copyRight';

const URL = `${window.location.origin}`;
export default {
  name: 'app',
  data() {
    return {
      navItems: [
        { label: '首页', path: '/' },
        { label: '产品列表', path: '/ProductsList' },
        { label: '规则引擎', path: '/RulesEngine' },
        { label: '状态监控', path: '/StatusMon' },
        { label: '边缘计算', path: '/EdgeManage' },
        { label: '数据分析', path: '/DataAnalysis' },
        { label: '平台监控', path: '' },
      ],
      headInfo: {
        userName: '未登录',
        noticeNum: 0,
        helpDocUrl: '#',
      },
    };
  },
  components: {
    breadCrumb,
    footerCopyright,
  },
  computed: {
    ...mapGetters([
      'navInfo',
    ]),
  },
  methods: {
    ...mapActions([
      'getUserInfo',
      'getNoticeNum',
      'getAllProducts',
      'getInitData',
      'getDynamicWidth',
    ]),
    toPortal() {
      const res = this.traffic.judgeUrl(URL);
      if (res === 'pro') { window.open('http://bdp.sf-express.com/'); return; }
      window.open(`http://bdp.${res}.sf-express.com/`);
    },
  },
  async created() {
    await this.getInitData();
    await this.getUserInfo();
    await this.getNoticeNum();
    this.headInfo = this.navInfo;
    await this.getAllProducts();
  },
  mounted() {
    this.getDynamicWidth();
  },
};
</script>
