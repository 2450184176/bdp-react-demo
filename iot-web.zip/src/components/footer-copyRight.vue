<template>
  <div class="footerStyle">
    <span>版权所有copyright@顺丰科技大数据平台部</span>
  </div>
</template>

<script>
export default {
  name: 'footer-copyRight',
};
</script>

