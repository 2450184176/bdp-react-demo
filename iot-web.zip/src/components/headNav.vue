<template lang="pug">
  #rview-head-nav
    nav
      .head-nav-logo
        slot(name='logo')
      .nav-menus
        ul.menu-items
          li.menu-item(ref='head-menu-item_0', :class="routerIndex===0 ? 'is-active' :''")
            router-link(to='/', target='_self') 首页
          li.menu-item(ref='head-menu-item_1', :class="routerIndex===1 ? 'is-active' :''")
            router-link(to='/ProductsList', target='_self') 产品列表
          li.menu-item(ref='head-menu-item_2', :class="routerIndex===2 ? 'is-active' :''")
            router-link(to='/RulesEngine', target='_self') 规则引擎
          li.menu-item(ref='head-menu-item_3', :class="routerIndex===3 ? 'is-active' :''")
            router-link(to='/StatusMon', target='_self') 状态监控
          li.menu-item.calculate(ref='head-menu-item_4', :class="routerIndex===4 ? 'is-active' :''")
            router-link(to='', target='_self') 边缘计算
          li.menu-item(ref='head-menu-item_5', :class="routerIndex===5 ? 'is-active' :''")
            router-link(to='/DataAnalysis', target='_self') 数据分析
          li.menu-item(ref='head-menu-item_6', :class="routerIndex===6 ? 'is-active' :''")
            p(@click="goToMon") 平台监控
          li.subMenu
            div
            div
              p(@click="$router.push({ path: '/EdgeManage/upPackage' })") OTA升级
              <!--p 边缘实例-->
        .move-line
          .nav-slider(:style='slideStyle')
      .user-info
        .user-notice
          a.btn(@click="toMsg" title='消息中心')
            i.iconfont.icon-lingdang
            .notice-num {{navInfo.noticeNum > 99 ? '99+' : (navInfo.noticeNum || 0)}}
        .help-doc
          a.iconfont.icon-office(:href="navInfo.helpDocUrl || ''", title='产品文档', target='_blank')
        .user-name
          span {{navInfo.userName || '未登录'}}
          i.fa.fa-caret-down.fa-down
          i.fa.fa-caret-up.fa-up
          ul.rview-dropdown
            li.rview-dropdown-item(v-for='(item,index) in dropdownMenu', :key='index')
              a(@click="goToPage(item)") {{item.label}}
            li.rview-dropdown-item
              a(href='javascript:void(0);', @click="$emit('logout')", target='_self')
                span 退出
                i.iconfont.icon-tuichu
</template>

<script>
const URL = `${window.location.origin}`;
export default {
  props: {
    menus: {
      type: Array,
      default() {
        return [
          { label: '首页', path: '#/one' },
          { label: '产品列表', path: '#/two' },
          { label: '规则引擎', path: '#/three' },
          { label: '状态监控', path: '#/four' },
          { label: '边缘计算', path: '#/five' },
          { label: '数据分析', path: '#/six' },
          { label: '平台监控', path: '#/seven' },
        ];
      },
    },
    pathRuler: Function,
    dropdownMenu: {
      type: Array,
      default() {
        return [
          { label: '控制台', url: 'consoleManage', id: 1 },
          { label: '我的流程', url: 'processCenter', id: 2 },
          { label: '我的应用', url: 'applicationCenter', id: 3 },
        ];
      },
    },
    navInfo: {
      type: Object,
      default() {
        return {
          userName: '未登录',
          noticeNum: 0,
          helpDocUrl: '#',
        };
      },
    },
  },
  data() {
    return {
      slideStyle: {},
      routerIndex: 0,
    };
  },
  created() {
    this.path2routerIndex(this.$route.path);
  },
  mounted() {
    this.setSlideStyle(this.routerIndex);
  },
  methods: {
    toMsg() {
      const res = this.traffic.judgeUrl(URL);
      if (res === 'pro') { window.open('http://bdp.sf-express.com/proc/#/messageCenter'); return; }
      window.open(`http://bdp.${res}.sf-express.com/proc/#/messageCenter`);
    },
    goToPage(oneData) {
      const res = this.traffic.judgeUrl(URL);
      if (res === 'pro') { window.open(`http://bdp.sf-express.com/proc/#/${oneData.url}`); return; }
      window.open(`http://bdp.${res}.sf-express.com/proc/#/${oneData.url}`);
    },
    path2routerIndex(path) {
      if (this.pathRuler) this.routerIndex = this.pathRuler(path, this.menus);
      else this.routerIndex = Math.max(this.menus.findIndex(menu => menu.path.replace('#', '') === path), 0);
    },
    setSlideStyle(key) {
      const node = this.$refs[`head-menu-item_${key}`];
      const width = node.offsetWidth / 2;
      const marginLeft = node.offsetLeft + (width / 2);
      this.slideStyle = {
        marginLeft: `${marginLeft}px`,
        width: `${width}px`,
        transition: '0.5s',
      };
    },
    goToMon() {
      const res = this.traffic.judgeUrl(URL);
      if (res === 'pro') { window.open('http://bdp-iot.sf-express.com/status'); return; }
      window.open(`http://bdp-iot.${res}.sf-express.com/status`);
    },
  },
  watch: {
    routerIndex(index) {
      this.$nextTick(() => {
        this.setSlideStyle(index);
      });
    },
    '$route.path': {
      async handler(path) {
        this.path2routerIndex(path);
        if (path === '/RuleDetail') { this.routerIndex = 2; }
        if (path.includes('/ProductDetail') || path.includes('/DeviceDetail')) { this.routerIndex = 1; }
        if (path.includes('/EdgeManage')) { this.routerIndex = 4; }
        if (path.includes('/upPackage')) { await this.$store.commit('setUpKind', '升级包'); }
        if (path.includes('/taskManage')) { await this.$store.commit('setUpKind', '升级任务'); }
        await this.$store.commit('updateBreadData', path);
      },
    },
  },
};
</script>

<style lang="scss" scoped>
  #rview-head-nav {
    width: 100%;
    height: 65px;
    background: #111f2a;
    color: #bfcbd9;
    padding: 0 20px 0 42px;
    min-width: 1355px;
    margin: 0;
    box-sizing: border-box;
    display: flex;
    justify-content: space-between;
    align-items: center;
    ul,li{
      list-style: none;
      cursor: context-menu;
    }
    a{
      text-decoration: none;
      color: #bfcbd9;
    }
    *{
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    nav{
      .head-nav-logo{
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        .log{
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
          margin-left: -15px;
          margin-top: 4px;
          cursor: pointer;
          .log-text{
            margin-top: -4px;
            margin-left: 20px;
          }
        }
      }
      flex: 1;
      display: flex;
      justify-content: flex-start;
      align-items: center;
      height: 100%;
      .nav-menus{
        margin-left: 20px;
        font-size: 16px;
        flex:1;
        height: 100%;
        display: flex;
        justify-content: flex-start;
        align-items: flex-start;
        flex-direction: column;
        .calculate:hover ~ .subMenu {
          div:nth-child(2) {
            transition: 0.6s all;
            display: block;
          }
        }
        ul.menu-items{
          flex: 1;
          display: flex;
          justify-content: flex-start;
          align-items: center;
          position: relative;
          .subMenu {
            position: absolute;
            z-index: 2333;
            left: 422px;
            top: 34.5px;
            cursor: pointer;
            div:nth-child(1) {
              height: 30px;
              background-color: transparent;
            }
            div:nth-child(2) {
              width: 120px;
              font-size: 14px;
              background: #404B54;
              border-radius: 0 0 4px 4px;
              display: none;
              p {
                text-align: center;
                padding: 12px 16px 12px 16px;
                &:hover {
                  background-color: #192732;
                  color: #20a2ff;
                  border-radius: 0 0 4px 4px;
                }
              }
            }
            &:hover > div:nth-child(2) {
              display: block;
            }
          }
          li.menu-item{
            cursor: pointer;
            margin: 0 25px;
            transition: all 0.1s ease;
            margin-bottom: -15px;
            & a:hover{
              border-color: #20a2ff;
              color: #20a2ff;
              transition: all 0.4s ease;
            }
            &.is-active a {
              transition: all 0.1s ease;
              color: #20a2ff;
            }
          }
        }
        .move-line{
          width: 100%;
          height: 3px;
          margin-bottom: 10px;
          .nav-slider{
            height: 100%;
            background: #20a2ff;
            border-radius: 3px;
            transition: all 0.2s ease;
          }
        }
      }
    }
    .user-info{
      display: flex;
      justify-content: flex-start;
      align-items: center;
      > * {
        margin:0 14px;
      }
      .help-doc{
        .iconfont{
          font-size: 20px;
          &:hover{
            color: #20a2ff;
          }
        }
      }
      .user-notice{
        position: relative;
        border:  1px solid #ebeef9;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 50%;
        width: 30px;
        height: 30px;
        margin-right: 30px;
        .btn:hover {
          cursor: pointer;
        }
        .iconfont{
          font-size: 20px;
        }
        &:hover{
          border-color: #20a2ff;
          .iconfont{
            color: #20a2ff;
          }
        }
        .notice-num{
          font-size: 12px;
          display: flex;
          justify-content: center;
          align-items: center;
          background: #fd8002;
          border-radius: 10px;
          height: 20px;
          padding: 0 7px;
          position: absolute;
          left: 24px;
          top: -4px;
        }
      }
      .user-name{
        font-size: 16px;
        padding: 0 25px;
        color: #bfcbd9;
        height: 30px;
        line-height: 30px;
        background: #111f2a;
        border-radius: 25px;
        cursor: pointer;
        position: relative;
        transition: all 0.1s ease;
        .fa-down {
          padding-left: 5px;
          display: inline-block;
        }
        .fa-up {
          padding-left: 5px;
          display: none;
        }
        .rview-dropdown{
          font-size: 14px;
          position: absolute;
          background: #111f2a;
          color: #bfcbd9;
          min-width: 100px;
          width: 120px;
          left: -6px;
          top: 30px;
          padding-top: 16px;
          box-shadow: 0 2px 4px rgba(0,0,0,.12),0 0 6px rgba(0,0,0,.12);
          background: rgba(17, 31, 42, 0.80);
          border-radius: 0 0 4px 4px;
          display: none;
          z-index: 99999;
          .rview-dropdown-item{
            padding: 5px 10px;
            text-align: center;
            cursor: pointer;
            &:last-of-type{
              border-top: 1px solid #5B6B78;
              border-radius:0 0 4px 4px;
              .iconfont{
                font-size: 18px;
                margin-left: 20px;
              }
            }
            &:hover{
              background: rgba(17, 31, 42, 0.80);
              a{
                color: #20a2ff;
                .iconfont{
                  color: #20a2ff;
                }
              }
            }
          }
        }
        &:hover{
          color: #20a2ff;
          border-color:#20a2ff;
          .fa-down {
            display: none;
            transition: all 0.5s ease;
          }
          .fa-up {
            display: inline-block;
            transition: all 0.5s ease;
          }
          .rview-dropdown{
            display: block;
            transition: all 0.5s ease;
          }
        }
      }
    }
  }
</style>
