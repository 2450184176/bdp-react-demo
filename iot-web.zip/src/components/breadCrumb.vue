<template>
  <div class="breadCrumb">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }" v-if="getBread.first">首页</el-breadcrumb-item>
      <el-breadcrumb-item :to="getBread.proUrl ? { path: `${ getBread.proUrl }` } : ''" v-if="getBread.first">{{ getBread.first }}</el-breadcrumb-item>
      <el-breadcrumb-item :to="getBread.proDetUrl ? { path: `${ getBread.proDetUrl }` } : ''" v-if="getBread.second">{{ getBread.second }}</el-breadcrumb-item>
      <el-breadcrumb-item :to="getBread.devDetUrl ? { path: `${ getBread.devDetUrl }` } : ''" v-if="getBread.third">{{ getBread.third }}</el-breadcrumb-item>
      <el-breadcrumb-item v-if="getBread.forth">{{ getBread.forth }}</el-breadcrumb-item>
    </el-breadcrumb>
  </div>
</template>
<script>
import { mapGetters } from 'vuex';

export default {
  name: 'breadCrumb',
  computed: {
    ...mapGetters([
      'getBread',
    ]),
  },
};
</script>
<style lang="scss" scoped>
  .breadCrumb{
    margin-bottom: 15px;
  }
</style>
