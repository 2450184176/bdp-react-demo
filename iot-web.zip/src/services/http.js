import axios from 'axios';
import { Message, MessageBox } from 'element-ui';
import util from '../lib/util';

axios.baseURL = {
  systemUrl: '/portal-web-system',
  loginUrl: '/iot-ctrl/usermanage/admin/system',
  mcCtrl: '/mc-ctrl',
  iot: '/iot-ctrl',
};
axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
axios.interceptors.request.use(
  config => config,
  err => Promise.reject(err),
);
axios.interceptors.response.use(
  (res) => {
    // 取消lid对应的loading
    if (res.data.status === 302) {
      util.deleteCookies();
      MessageBox.alert(res.data.msg || res.data.errMsg, '提示', {
        confirmButtonText: '确定',
        type: 'warning',
        callback: () => {
          window.location.href = axios.baseURL.loginUrl;
        },
      });
      return false;
    }
    // 全局统一出错处理
    if (!res.data.ok) {
      if (res.data.errMsg) {
        Message.error(res.data.errMsg);
      }
      return false;
    }
    return res.data.data;
  },
  error =>
    Promise.reject(error.response),
);
export default axios;
