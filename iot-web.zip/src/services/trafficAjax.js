import qs from 'qs';
import { Message } from 'element-ui';
import axios from './http';

export default {
  getOnOffEquips(obj) {
    return axios.get(`${axios.baseURL.iot}/index/equipmentCount`, {
      params: obj,
    });
  },
  getUpMessage(obj) {
    return axios.get(`${axios.baseURL.iot}/index/collectCount`, {
      params: obj,
    });
  },
  getRules(obj) {
    return axios.get(`${axios.baseURL.iot}/index/forwardCount`, {
      params: obj,
    });
  },
  getEquipSituation() {
    return axios.get(`${axios.baseURL.iot}/index/index`);
  },
  productList(obj) {
    return axios({
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'post',
      url: `${axios.baseURL.iot}/product/page`,
      data: qs.stringify(obj),
    });
  },
  addPro(obj) {
    const params = {};
    params.productName = obj.productName;
    params.productType = obj.productType;
    params.protocolType = obj.protocolType;
    params.remark = obj.remark;
    if (obj.userIds.length) params.userIds = String(obj.userIds);
    if (obj.protocolType === 'HTTP') params.productKey = obj.productKey;
    if (obj.protocolType === 'MQTT') params.transparent = Number(obj.transparent);
    return axios({
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'post',
      url: `${axios.baseURL.iot}/product/save`,
      data: qs.stringify(params),
    });
  },
  deletePro(obj) {
    return axios.delete(`${axios.baseURL.iot}/product/delete?id=${obj.id}`);
  },
  addLabel(obj) {
    // eslint-disable-next-line
    obj.labels = JSON.stringify(obj.labels);
    return axios({
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'post',
      url: `${axios.baseURL.iot}/product/addLable`,
      data: qs.stringify(obj),
    });
  },
  deleteLabel(obj) {
    return axios.delete(`${axios.baseURL.iot}/product/delLable?id=${obj.id}`);
  },
  deleteDevice(obj) {
    return axios.delete(`${axios.baseURL.iot}/device/delete?id=${obj.id}`);
  },
  addDevice(obj) {
    return axios({
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'post',
      url: `${axios.baseURL.iot}/device/save`,
      data: qs.stringify(obj),
    });
  },
  upFiles(obj) {
    return axios({
      method: 'post',
      url: `${axios.baseURL.iot}/device/batchUpload`,
      data: obj,
    });
  },
  upGradeTasks(obj) {
    return axios({
      method: 'post',
      url: `${axios.baseURL.iot}/upgrade/saveTask`,
      data: qs.stringify(obj),
    });
  },
  tasksLists(obj) {
    return axios.get(`${axios.baseURL.iot}/upgrade/pageTask`, { params: obj });
  },
  upPackageAjax(obj) {
    return axios({
      method: 'post',
      url: `${axios.baseURL.iot}/upgrade/savePackage`,
      data: obj,
    });
  },
  allPackages(obj) {
    return axios.get(`${axios.baseURL.iot}/upgrade/page`, {
      params: obj,
    });
  },
  taskDetailDevice(obj) {
    return axios.get(`${axios.baseURL.iot}/upgrade/pageUpgradeInfo`, { params: obj });
  },
  taskDetails(obj) {
    return axios.get(`${axios.baseURL.iot}/upgrade/taskDetail`, { params: obj });
  },
  checkPackage(obj) {
    return axios({
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'post',
      url: `${axios.baseURL.iot}/upgrade/verifyPackage`,
      data: qs.stringify(obj),
    });
  },
  addBatchDevices(obj) {
    return axios({
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'post',
      url: `${axios.baseURL.iot}/device/batchGenerate`,
      data: qs.stringify(obj),
    });
  },
  devicesList(obj) {
    return axios.get(`${axios.baseURL.iot}/device/page`, {
      params: obj,
    });
  },
  deviceDetails(obj) {
    return axios.get(`${axios.baseURL.iot}/device/detail`, {
      params: obj,
    });
  },
  proTopicList(obj) {
    return axios.get(`${axios.baseURL.iot}/product/topicList`, {
      params: obj,
    });
  },
  devTopicList(obj) {
    return axios.get(`${axios.baseURL.iot}/device/topicList`, {
      params: obj,
    });
  },
  async addMesInfo(obj, vmo) {
    const tempObj = {
      dataStructure: {
        fields: [],
      },
    };
    if (obj.editId) { tempObj.id = obj.editId; }
    tempObj.productId = obj.productId;
    tempObj.remark = obj.remark;
    tempObj.topicName = obj.realTopicName;
    tempObj.rightValue = Number(obj.rightValue);
    tempObj.protoDataId = Number(obj.protoDataId);
    tempObj.dataStructure.cmd = Number(obj.rightValue);
    tempObj.dataStructure.id = Number(obj.protoDataId);
    tempObj.dataStructure.length = typeof obj.length === 'string' ? obj.length : Number(obj.length);
    obj.dataStructure.fields.forEach(async (item, index) => {
      const ttObj = {};
      ttObj.index = index;
      ttObj.name = item.name;
      ttObj.length = item.length;
      ttObj.type = item.type;
      ttObj.value = '';
      tempObj.dataStructure.fields.push(ttObj);
    });
    tempObj.dataStructure = JSON.stringify(tempObj.dataStructure);
    const resPost = await axios({
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'post',
      url: `${axios.baseURL.iot}/product/addTopic`,
      data: qs.stringify(tempObj),
    });
    // eslint-disable-next-line
    vmo.topicVisible = false;
    if (resPost) { Message.success(resPost); vmo.loadProTopics(); }
  },
  getMegItem(obj) {
    return axios.get(`${axios.baseURL.iot}/product/topicDetail`, {
      params: obj,
    });
  },
  deleteItem(obj) {
    return axios.delete(`${axios.baseURL.iot}/product/delTopic?topicId=${obj.id}`);
  },
  rulesList(obj) {
    return axios.get(`${axios.baseURL.iot}/rule/page`, {
      params: obj,
    });
  },
  add1Rule(obj) {
    return axios({
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'post',
      url: `${axios.baseURL.iot}/rule/save`,
      data: qs.stringify(obj),
    });
  },
  forwardInfoList(obj) {
    return axios.get(`${axios.baseURL.iot}/rule/listForward`, {
      params: obj,
    });
  },
  delete1Forward(obj) {
    return axios.delete(`${axios.baseURL.iot}/rule/delForward?forwardId=${obj.forwardId}`);
  },
  testConnection(obj) {
    return axios({
      url: `${axios.baseURL.iot}/rule/testConnect`,
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      data: qs.stringify(obj),
      method: 'post',
    });
  },
  addForwardInfo(obj) {
    if (!obj.id) {
      // eslint-disable-next-line
      delete obj.id;
    }
    return axios({
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'post',
      url: `${axios.baseURL.iot}/rule/saveForward`,
      data: qs.stringify(obj),
    });
  },
  delete1rule(obj) {
    return axios.delete(`${axios.baseURL.iot}/rule/delete?id=${obj.id}`);
  },
  ruleDetails(obj) {
    return axios.get(`${axios.baseURL.iot}/rule/detail`, {
      params: obj,
    });
  },
  ruleStartOrStop(obj) {
    return axios({
      headers: {
        'content-type': 'application/x-www-form-urlencoded',
      },
      method: 'post',
      url: `${axios.baseURL.iot}/rule/start`,
      data: qs.stringify(obj),
    });
  },
  getAllTopic(obj) {
    return axios.get(`${axios.baseURL.iot}/product/allTopic`, {
      params: obj,
    });
  },
  getKafkaTopic(obj) {
    return axios.get(`${axios.baseURL.iot}/kafka/topicList`, {
      params: obj,
    });
  },
};
