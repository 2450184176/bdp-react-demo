import Vue from 'vue';
import elementUI from 'element-ui';
import eCharts from 'echarts';
import HeadNav from '@/components/headNav';
import 'static/font/iconfont/iconfont.css';
import 'element-ui/lib/theme-chalk/index.css';
import VueClipboard from 'vue-clipboard2';
import animated from 'animate.css';
import Fetch from './services/trafficAjax';
import store from './store';
import router from './router';
import './lib';
import App from './App';


Vue.use(elementUI);
Vue.use(animated);
Vue.use(VueClipboard);
Vue.component('HeadNav', HeadNav);
Vue.config.productionTip = false;
Vue.prototype.$Fetch = Fetch;
Vue.prototype.$eCharts = eCharts;
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App),
});
