/* eslint-disable no-param-reassign */
/* eslint-disable no-shadow */
/* eslint-disable no-console */
import { MessageBox } from 'element-ui';
import axios from '../../services/http';
import util from '../../lib/util';

const state = {
  userInfo: {},
  navInfo: {},
  breadData: '',
  initData: {},
  proDetailData: {},
  allPros: [],
  productId: '',
  deviceId: '',
  deviceDetail: {},
  upKind: '升级包',
  dynamicWidth: '',
};

const getters = {
  navInfo(state) {
    const environment = window.location.host;
    if (environment.includes('iot.sf') || environment.includes('idap.sf')) {
      return Object.assign(state.navInfo, { helpDocUrl: 'http://bdp-iot.sf-express.com/help/docs/iot/250' });
    }
    return Object.assign(state.navInfo, { helpDocUrl: 'http://10.117.176.210:8181/docs/iot/251' });
  },
  userName: state => state.userInfo.name,
  userId: state => state.userInfo.id,
  userType: state => state.userInfo.type,
  userInfo: state => state.userInfo,
  getClusters: state => state.initData,
  getBread(state) {
    const tempBread = state.breadData;
    const forOut = {};
    const productId = state.productId;
    switch (tempBread) {
      case '/ProductsList':
        forOut.first = '产品列表';
        return forOut;
      case '/RulesEngine':
        forOut.first = '规则引擎';
        return forOut;
      case '/EdgeManage/upPackage':
        forOut.first = '升级包列表';
        return forOut;
      case '/EdgeManage/taskManage':
        forOut.first = '升级任务列表';
        return forOut;
      case '/EdgeManage/taskDetails':
        forOut.first = '升级任务列表';
        forOut.second = '任务详情';
        forOut.proUrl = '/EdgeManage/taskManage';
        return forOut;
      case '/DataAnalysis':
        forOut.first = '数据分析';
        return forOut;
      case '/StatusMon':
        forOut.first = '状态监控';
        return forOut;
      case '/ProductDetail':
        forOut.first = '产品列表';
        forOut.second = '产品详情';
        forOut.proUrl = '/ProductsList';
        return forOut;
      case '/ProductDetail/ProInfo':
        forOut.first = '产品列表';
        forOut.second = '产品详情';
        forOut.proUrl = '/ProductsList';
        return forOut;
      case '/ProductDetail/InfoTel':
        forOut.first = '产品列表';
        forOut.second = '产品详情';
        forOut.proUrl = '/ProductsList';
        return forOut;
      case '/ProductDetail/SerSub':
        forOut.first = '产品列表';
        forOut.second = '产品详情';
        forOut.proUrl = '/ProductsList';
        return forOut;
      case '/ProductDetail/LogSer':
        forOut.first = '产品列表';
        forOut.second = '产品详情';
        forOut.proUrl = '/ProductsList';
        return forOut;
      case '/ProductDetail/DeviceList':
        forOut.first = '产品列表';
        forOut.second = '产品详情';
        forOut.third = '设备列表';
        forOut.proUrl = '/ProductsList';
        forOut.proDetUrl = `/ProductDetail/ProInfo?productId=${productId}`;
        return forOut;
      case '/DeviceDetail/DevInfo':
        forOut.first = '产品列表';
        forOut.second = '产品详情';
        forOut.third = '设备列表';
        forOut.forth = '设备详情';
        forOut.proUrl = '/ProductsList';
        forOut.proDetUrl = `/ProductDetail/ProInfo?productId=${productId}`;
        forOut.devDetUrl = `/ProductDetail/DeviceList?productId=${productId}`;
        return forOut;
      case '/DeviceDetail/DevTel':
        forOut.first = '产品列表';
        forOut.second = '产品详情';
        forOut.third = '设备列表';
        forOut.forth = '设备详情';
        forOut.proUrl = '/ProductsList';
        forOut.proDetUrl = `/ProductDetail/ProInfo?productId=${productId}`;
        forOut.devDetUrl = `/ProductDetail/DeviceList?productId=${productId}`;
        return forOut;
      case '/DeviceDetail/DevSha':
        forOut.first = '产品列表';
        forOut.second = '产品详情';
        forOut.third = '设备列表';
        forOut.forth = '设备详情';
        forOut.proUrl = `/ProductsList?productId=${productId}`;
        forOut.proDetUrl = `/ProductDetail/ProInfo?productId=${productId}`;
        forOut.devDetUrl = `/ProductDetail/DeviceList?productId=${productId}`;
        return forOut;
      case '/RuleDetail':
        forOut.first = '规则列表';
        forOut.second = '规则详情';
        forOut.proUrl = '/RulesEngine';
        return forOut;
      default:
        return forOut;
    }
  },
  getProDetails: state => state.proDetailData,
  getLabels: state => state.proDetailData.labels,
  getAllPros: state => state.allPros,
  getDeviceId: state => state.deviceId,
  getDeviceDetails: state => state.deviceDetail,
  getUpKind: state => state.upKind,
  getDynamicWidth: state => state.dynamicWidth,
};

const mutations = {
  setUserInfo(state, userInfo) {
    state.userInfo = userInfo;
  },
  clearUserInfo(state) {
    state.userInfo = {};
    state.navInfo = {};
  },
  setNavInfo(state, navInfo) {
    if (navInfo) state.navInfo = Object.assign(state.navInfo, navInfo);
  },
  updateBreadData(state, breadData) {
    if (breadData) state.breadData = breadData;
  },
  setInitData(state, initData) {
    state.initData = initData;
  },
  setProDetailData(state, proDetail) {
    state.proDetailData = proDetail;
  },
  setAllProData(state, allPros) {
    state.allPros = allPros;
  },
  setDevId(state, id) {
    state.deviceId = id;
  },
  setDeviceDetail(state, res) {
    state.deviceDetail = res;
  },
  setProId(state, proId) {
    state.productId = proId;
  },
  setUpKind(state, upKind) {
    state.upKind = upKind;
  },
  setWindowWidth(state, width) {
    state.dynamicWidth = width;
  },
};

const actions = {
  userLogOut({ commit }) {
    MessageBox.confirm('你确定退出登录么？', '提示', {
      type: 'warning',
    }).then(() => {
      util.deleteCookies();
      commit('clearUserInfo');
      window.location.href = '/portal-web-system/usermanage/admin/loginOut';
    }).catch(() => {});
  },
  async getUserInfo({ commit }) {
    const res = await axios.get(`${axios.baseURL.systemUrl}/usermanage/admin/getUser`);
    if (res) {
      commit('setUserInfo', res || {});
      commit('setNavInfo', { userName: res.name });
    } else {
      commit('clearUserInfo');
      util.deleteCookies();
      MessageBox.alert('请重新登录', '提示', {
        confirmButtonText: '确定',
        type: 'warning',
        callback: () => { window.location.href = axios.baseURL.loginUrl; },
      });
    }
  },
  async getInitData({ commit }) {
    const res = await axios.get(`${axios.baseURL.iot}/index/initData`);
    commit('setInitData', res);
  },
  async getProDetail({ commit }, productId) {
    const params = { id: productId };
    const res = await axios.get(`${axios.baseURL.iot}/product/detail`, { params });
    if (res) { commit('setProDetailData', res); }
  },
  async getAllProducts({ commit }) {
    const res = await axios.get(`${axios.baseURL.iot}/product/allProducts`);
    if (res) { commit('setAllProData', res); }
  },
  async getDeviceDetail({ commit }, deviceId) {
    const params = { id: deviceId };
    const res = await axios.get(`${axios.baseURL.iot}/device/detail`, { params });
    localStorage.setItem('proId', res.productId);
    localStorage.setItem('shadow', res.shadow);
    if (res) { commit('setDeviceDetail', res); commit('setProId', res.productId); }
  },
  async getNoticeNum({ commit }) {
    const res = await axios.get(`${axios.baseURL.mcCtrl}/message/unreadCount`);
    commit('setNavInfo', { noticeNum: res });
  },
  getDynamicWidth({ commit }) {
    const width = window.screen.availWidth;
    commit('setWindowWidth', width);
  },
};
export default {
  // namespaced: true 激活命名空间
  state,
  mutations,
  actions,
  getters,
};
